#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class RAMDCharacterDbModelImpl, RAMDRuntimeQuery<__covariant RowType>, RAMDRuntimeTransacterTransaction, RAMDSourceType, RAMDCharacter, RAMDCharacters, RAMDKotlinThrowable, RAMDKotlinArray<T>, RAMDKotlinException, RAMDKotlinRuntimeException, RAMDKotlinEnum<E>, RAMDResultResponse, RAMDCharactersResponse, RAMDApollo_runtime_kotlinApolloClient, RAMDOkioByteString, RAMDApollo_apiScalarTypeAdapters, RAMDApollo_apiResponse<T>, RAMDApollo_apiOperationVariables, RAMDDataModelResponseQueryData, RAMDDataModelResponseQueryCharacters, RAMDDataModelResponseQueryResult, RAMDCustomType, RAMDEval<__covariant A>, RAMDEither<__covariant A, __covariant B>, RAMDKotlinNothing, RAMDEitherLeft<__covariant A>, RAMDEitherRight<__covariant B>, RAMDEvalAlways<__covariant A>, RAMDEvalLater<__covariant A>, RAMDEvalNow<__covariant A>, RAMDKotlinUnit, RAMDMpTry<__covariant A>, RAMDMpTryFailure, RAMDMpTrySuccess<__covariant A>, RAMDOption<__covariant A>, RAMDSome<__covariant T>, RAMDTryException, RAMDTryExceptionPredicateException, RAMDTryExceptionUnsupportedOperationException, RAMDDeriving<A>, RAMDMapperManagerCompanion, RAMDCharactersServiceCompanion, RAMDKotlinPair<__covariant A, __covariant B>, RAMDKotlinByteArray, RAMDApollo_apiResponseBuilder<T>, RAMDApollo_apiError, RAMDOkioBuffer, RAMDOkioTimeout, RAMDApollo_apiResponseField, RAMDApollo_apiResponseFieldCustomTypeField, RAMDKtor_client_coreHttpClient, RAMDKtor_client_coreHttpClientEngineConfig, RAMDKotlinx_coroutines_coreCoroutineDispatcher, RAMDKotlinx_serialization_runtimeSerialKind, RAMDKotlinx_serialization_runtimeUpdateMode, RAMDApollo_runtime_kotlinGraphQLRequest, RAMDApollo_runtime_kotlinApolloRequest<T>, RAMDKotlinByteIterator, RAMDApollo_apiCustomTypeValue<T>, RAMDApollo_apiErrorLocation, RAMDApollo_apiResponseFieldCondition, RAMDApollo_apiResponseFieldType, RAMDKtor_client_coreHttpClientConfig<T>, RAMDKtor_client_coreHttpReceivePipeline, RAMDKtor_client_coreHttpRequestPipeline, RAMDKtor_client_coreHttpResponsePipeline, RAMDKtor_client_coreHttpSendPipeline, RAMDKtor_client_coreProxyConfig, RAMDKotlinAbstractCoroutineContextElement, RAMDKtor_utilsAttributeKey<T>, RAMDKtor_utilsPipelinePhase, RAMDKtor_utilsPipeline<TSubject, TContext>, RAMDKtor_client_coreHttpResponse, RAMDKtor_client_coreHttpClientCall, RAMDKtor_client_coreHttpRequestBuilder, RAMDKtor_client_coreHttpResponseContainer, RAMDKtor_httpUrl, RAMDKtor_utilsGMTDate, RAMDKtor_httpHttpStatusCode, RAMDKtor_httpHttpProtocolVersion, RAMDKtor_httpHeadersBuilder, RAMDKtor_client_coreHttpRequestData, RAMDKtor_httpURLBuilder, RAMDKtor_httpHttpMethod, RAMDKtor_client_coreTypeInfo, RAMDKtor_httpURLProtocol, RAMDKtor_ioByteOrder, RAMDKtor_utilsWeekDay, RAMDKtor_utilsMonth, RAMDKtor_httpOutgoingContent, RAMDKtor_utilsStringValuesBuilder, RAMDKtor_httpParametersBuilder, RAMDKotlinx_coroutines_coreCancellationException, RAMDKtor_ioIoBuffer, RAMDKtor_httpContentType, RAMDKotlinIllegalStateException, RAMDKotlinKTypeProjection, RAMDKtor_ioMemory, RAMDKtor_ioBuffer, RAMDKtor_ioChunkBuffer, RAMDKotlinCharArray, RAMDKtor_httpHeaderValueParam, RAMDKtor_httpHeaderValueWithParameters, RAMDKotlinx_coroutines_coreAtomicDesc, RAMDKotlinx_coroutines_corePrepareOp, RAMDKotlinKVariance, RAMDKotlinCharIterator, RAMDKotlinx_coroutines_coreAtomicOp<__contravariant T>, RAMDKotlinx_coroutines_coreOpDescriptor, RAMDKotlinx_coroutines_coreLinkedListNode, RAMDKotlinx_coroutines_coreAbstractAtomicDesc;

@protocol RAMDCharacterDbModel, RAMDRuntimeTransacter, RAMDCharacterDbModelQueries, RAMDRickAndMortyDb, RAMDRuntimeSqlDriver, RAMDRuntimeSqlDriverSchema, RAMDCharactersService, RAMDKotlinComparable, RAMDDataNet, RAMDKotlinx_serialization_runtimeKSerializer, RAMDKotlinSuspendFunction1, RAMDKotlinKClass, RAMDRemoteDataSource, RAMDNetConfig, RAMDApollo_apiOperationName, RAMDOkioBufferedSource, RAMDApollo_apiResponseFieldMapper, RAMDApollo_apiOperationData, RAMDApollo_apiOperation, RAMDApollo_apiQuery, RAMDApollo_apiResponseFieldMarshaller, RAMDApollo_apiResponseReader, RAMDApollo_apiScalarType, RAMDKind, RAMDMapperManager, RAMDLogger, RAMDKtor_client_coreHttpClientEngine, RAMDCharacterUseCase, RAMDLocalDataSource, RAMDConfigDSL, RAMDRuntimeSqlCursor, RAMDRuntimeQueryListener, RAMDRuntimeSqlPreparedStatement, RAMDRuntimeCloseable, RAMDKotlinIterator, RAMDKotlinx_serialization_runtimeEncoder, RAMDKotlinx_serialization_runtimeSerialDescriptor, RAMDKotlinx_serialization_runtimeSerializationStrategy, RAMDKotlinx_serialization_runtimeDecoder, RAMDKotlinx_serialization_runtimeDeserializationStrategy, RAMDKotlinFunction, RAMDKotlinKDeclarationContainer, RAMDKotlinKAnnotatedElement, RAMDKotlinKClassifier, RAMDApollo_runtime_kotlinNetworkTransport, RAMDApollo_runtime_kotlinApolloRequestInterceptor, RAMDApollo_apiExecutionContext, RAMDApollo_runtime_kotlinApolloMutationCall, RAMDApollo_apiMutation, RAMDApollo_runtime_kotlinApolloQueryCall, RAMDApollo_apiCustomTypeAdapter, RAMDOkioSink, RAMDOkioSource, RAMDApollo_apiInputFieldMarshaller, RAMDApollo_apiResponseWriter, RAMDApollo_apiResponseReaderObjectReader, RAMDApollo_apiResponseReaderListItemReader, RAMDApollo_apiResponseReaderListReader, RAMDKtor_client_coreHttpClientEngineCapability, RAMDKotlinCoroutineContext, RAMDKotlinx_coroutines_coreCoroutineScope, RAMDKtor_ioCloseable, RAMDKotlinx_serialization_runtimeCompositeEncoder, RAMDKotlinx_serialization_runtimeSerialModule, RAMDKotlinAnnotation, RAMDKotlinx_serialization_runtimeCompositeDecoder, RAMDKotlinx_coroutines_coreFlow, RAMDApollo_runtime_kotlinApolloInterceptorChain, RAMDApollo_apiExecutionContextElement, RAMDApollo_apiExecutionContextKey, RAMDApollo_runtime_kotlinApolloCall, RAMDOkioBufferedSink, RAMDApollo_apiInputFieldWriter, RAMDApollo_apiResponseWriterListItemWriter, RAMDApollo_apiResponseWriterListWriter, RAMDKtor_utilsAttributes, RAMDKotlinCoroutineContextKey, RAMDKotlinCoroutineContextElement, RAMDKotlinContinuation, RAMDKotlinContinuationInterceptor, RAMDKotlinx_coroutines_coreRunnable, RAMDKotlinx_serialization_runtimeSerialModuleCollector, RAMDApollo_apiInputFieldWriterListItemWriter, RAMDApollo_apiInputFieldWriterListWriter, RAMDKtor_client_coreHttpClientFeature, RAMDKotlinSuspendFunction2, RAMDKtor_httpHeaders, RAMDKtor_httpHttpMessage, RAMDKtor_ioByteReadChannel, RAMDKtor_client_coreHttpRequest, RAMDKtor_httpHttpMessageBuilder, RAMDKotlinx_coroutines_coreJob, RAMDKtor_httpParameters, RAMDKotlinMapEntry, RAMDKtor_utilsStringValues, RAMDKtor_ioReadSession, RAMDKotlinx_coroutines_coreChildHandle, RAMDKotlinx_coroutines_coreChildJob, RAMDKotlinx_coroutines_coreDisposableHandle, RAMDKotlinSequence, RAMDKotlinx_coroutines_coreSelectClause0, RAMDKtor_client_coreType, RAMDKotlinKType, RAMDKotlinx_coroutines_coreParentJob, RAMDKotlinx_coroutines_coreSelectInstance, RAMDKotlinSuspendFunction0, RAMDKtor_ioObjectPool, RAMDKtor_ioInput, RAMDKotlinAppendable, RAMDKtor_ioOutput;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wnullability"

__attribute__((swift_name("KotlinBase")))
@interface RAMDBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface RAMDBase (RAMDBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface RAMDMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface RAMDMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorRAMDKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface RAMDNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface RAMDByte : RAMDNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface RAMDUByte : RAMDNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface RAMDShort : RAMDNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface RAMDUShort : RAMDNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface RAMDInt : RAMDNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface RAMDUInt : RAMDNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface RAMDLong : RAMDNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface RAMDULong : RAMDNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface RAMDFloat : RAMDNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface RAMDDouble : RAMDNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface RAMDBoolean : RAMDNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((swift_name("CharacterDbModel")))
@protocol RAMDCharacterDbModel
@required
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) int64_t idCharacter __attribute__((swift_name("idCharacter")));
@property (readonly) NSString * _Nullable image __attribute__((swift_name("image")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) RAMDLong * _Nullable page __attribute__((swift_name("page")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharacterDbModelImpl")))
@interface RAMDCharacterDbModelImpl : RAMDBase <RAMDCharacterDbModel>
- (instancetype)initWithId:(int64_t)id idCharacter:(int64_t)idCharacter page:(RAMDLong * _Nullable)page name:(NSString * _Nullable)name image:(NSString * _Nullable)image status:(NSString * _Nullable)status __attribute__((swift_name("init(id:idCharacter:page:name:image:status:)"))) __attribute__((objc_designated_initializer));
- (int64_t)component1 __attribute__((swift_name("component1()")));
- (int64_t)component2 __attribute__((swift_name("component2()")));
- (RAMDLong * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (NSString * _Nullable)component6 __attribute__((swift_name("component6()")));
- (RAMDCharacterDbModelImpl *)doCopyId:(int64_t)id idCharacter:(int64_t)idCharacter page:(RAMDLong * _Nullable)page name:(NSString * _Nullable)name image:(NSString * _Nullable)image status:(NSString * _Nullable)status __attribute__((swift_name("doCopy(id:idCharacter:page:name:image:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) int64_t idCharacter __attribute__((swift_name("idCharacter")));
@property (readonly) NSString * _Nullable image __attribute__((swift_name("image")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) RAMDLong * _Nullable page __attribute__((swift_name("page")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((swift_name("RuntimeTransacter")))
@protocol RAMDRuntimeTransacter
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(RAMDRuntimeTransacterTransaction *))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
@end;

__attribute__((swift_name("CharacterDbModelQueries")))
@protocol RAMDCharacterDbModelQueries <RAMDRuntimeTransacter>
@required
- (void)deleteAll __attribute__((swift_name("deleteAll()")));
- (void)insertCharacterIdCharacter:(int64_t)idCharacter name:(NSString * _Nullable)name page:(RAMDLong * _Nullable)page image:(NSString * _Nullable)image status:(NSString * _Nullable)status __attribute__((swift_name("insertCharacter(idCharacter:name:page:image:status:)")));
- (RAMDRuntimeQuery<id<RAMDCharacterDbModel>> *)selectAll __attribute__((swift_name("selectAll()")));
- (RAMDRuntimeQuery<id> *)selectAllMapper:(id (^)(RAMDLong *, RAMDLong *, RAMDLong * _Nullable, NSString * _Nullable, NSString * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("selectAll(mapper:)")));
- (RAMDRuntimeQuery<id<RAMDCharacterDbModel>> *)selectMoviesByIdIdCharacter:(int64_t)idCharacter __attribute__((swift_name("selectMoviesById(idCharacter:)")));
- (RAMDRuntimeQuery<id> *)selectMoviesByIdIdCharacter:(int64_t)idCharacter mapper:(id (^)(RAMDLong *, RAMDLong *, RAMDLong * _Nullable, NSString * _Nullable, NSString * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("selectMoviesById(idCharacter:mapper:)")));
- (RAMDRuntimeQuery<id<RAMDCharacterDbModel>> *)selectMoviesByNameName:(NSString * _Nullable)name __attribute__((swift_name("selectMoviesByName(name:)")));
- (RAMDRuntimeQuery<id> *)selectMoviesByNameName:(NSString * _Nullable)name mapper:(id (^)(RAMDLong *, RAMDLong *, RAMDLong * _Nullable, NSString * _Nullable, NSString * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("selectMoviesByName(name:mapper:)")));
@end;

__attribute__((swift_name("RickAndMortyDb")))
@protocol RAMDRickAndMortyDb <RAMDRuntimeTransacter>
@required
@property (readonly) id<RAMDCharacterDbModelQueries> characterDbModelQueries __attribute__((swift_name("characterDbModelQueries")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RickAndMortyDbCompanion")))
@interface RAMDRickAndMortyDbCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<RAMDRickAndMortyDb>)invokeDriver:(id<RAMDRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<RAMDRuntimeSqlDriverSchema> Schema __attribute__((swift_name("Schema")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Character")))
@interface RAMDCharacter : RAMDBase
- (instancetype)initWithId:(int32_t)id name:(NSString *)name status:(NSString *)status image:(NSString *)image sourceType:(RAMDSourceType *)sourceType __attribute__((swift_name("init(id:name:status:image:sourceType:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (RAMDSourceType *)component5 __attribute__((swift_name("component5()")));
- (RAMDCharacter *)doCopyId:(int32_t)id name:(NSString *)name status:(NSString *)status image:(NSString *)image sourceType:(RAMDSourceType *)sourceType __attribute__((swift_name("doCopy(id:name:status:image:sourceType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@property (readonly) NSString *image __attribute__((swift_name("image")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) RAMDSourceType *sourceType __attribute__((swift_name("sourceType")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Characters")))
@interface RAMDCharacters : RAMDBase
- (instancetype)initWithResults:(NSArray<RAMDCharacter *> *)results __attribute__((swift_name("init(results:)"))) __attribute__((objc_designated_initializer));
- (NSArray<RAMDCharacter *> *)component1 __attribute__((swift_name("component1()")));
- (RAMDCharacters *)doCopyResults:(NSArray<RAMDCharacter *> *)results __attribute__((swift_name("doCopy(results:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<RAMDCharacter *> *results __attribute__((swift_name("results")));
@end;

__attribute__((swift_name("Logger")))
@protocol RAMDLogger
@required
- (void)logTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("log(tag:message:)")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface RAMDKotlinThrowable : RAMDBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (RAMDKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("KotlinException")))
@interface RAMDKotlinException : RAMDKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinRuntimeException")))
@interface RAMDKotlinRuntimeException : RAMDKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NativeRuntimeException")))
@interface RAMDNativeRuntimeException : RAMDKotlinRuntimeException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NoDataFound")))
@interface RAMDNoDataFound : RAMDKotlinRuntimeException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((swift_name("RuntimeSqlDriverSchema")))
@protocol RAMDRuntimeSqlDriverSchema
@required
- (void)createDriver:(id<RAMDRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (void)migrateDriver:(id<RAMDRuntimeSqlDriver>)driver oldVersion:(int32_t)oldVersion newVersion:(int32_t)newVersion __attribute__((swift_name("migrate(driver:oldVersion:newVersion:)")));
@property (readonly) int32_t version __attribute__((swift_name("version")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Schema")))
@interface RAMDSchema : RAMDBase <RAMDRuntimeSqlDriverSchema>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)schema __attribute__((swift_name("init()")));
- (void)createDriver:(id<RAMDRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (void)migrateDriver:(id<RAMDRuntimeSqlDriver>)driver oldVersion:(int32_t)oldVersion newVersion:(int32_t)newVersion __attribute__((swift_name("migrate(driver:oldVersion:newVersion:)")));
@property (readonly) int32_t version __attribute__((swift_name("version")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLocator")))
@interface RAMDServiceLocator : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serviceLocator __attribute__((swift_name("init()")));
@property (readonly) id<RAMDCharactersService> uc __attribute__((swift_name("uc")));
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol RAMDKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface RAMDKotlinEnum<E> : RAMDBase <RAMDKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SourceType")))
@interface RAMDSourceType : RAMDKotlinEnum<RAMDSourceType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDSourceType *net __attribute__((swift_name("net")));
@property (class, readonly) RAMDSourceType *db __attribute__((swift_name("db")));
- (int32_t)compareToOther:(RAMDSourceType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("DataNet")))
@protocol RAMDDataNet
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharactersResponse")))
@interface RAMDCharactersResponse : RAMDBase <RAMDDataNet>
- (instancetype)initWithResults:(NSArray<RAMDResultResponse *> *)results __attribute__((swift_name("init(results:)"))) __attribute__((objc_designated_initializer));
- (NSArray<RAMDResultResponse *> *)component1 __attribute__((swift_name("component1()")));
- (RAMDCharactersResponse *)doCopyResults:(NSArray<RAMDResultResponse *> *)results __attribute__((swift_name("doCopy(results:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<RAMDResultResponse *> *results __attribute__((swift_name("results")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharactersResponse.Companion")))
@interface RAMDCharactersResponseCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<RAMDKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("MapperManager")))
@protocol RAMDMapperManager
@required
- (id<RAMDKotlinSuspendFunction1>)getListMapperModelClass:(id<RAMDKotlinKClass>)modelClass __attribute__((swift_name("getListMapper(modelClass:)")));
- (id<RAMDKotlinSuspendFunction1>)getMapperModelClass:(id<RAMDKotlinKClass>)modelClass __attribute__((swift_name("getMapper(modelClass:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MapperManagerCompanion")))
@interface RAMDMapperManagerCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("RemoteDataSource")))
@protocol RAMDRemoteDataSource
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceGraphQl")))
@interface RAMDRemoteDataSourceGraphQl : RAMDBase <RAMDRemoteDataSource>
- (instancetype)initWithApolloClient:(RAMDApollo_runtime_kotlinApolloClient *)apolloClient __attribute__((swift_name("init(apolloClient:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResultResponse")))
@interface RAMDResultResponse : RAMDBase <RAMDDataNet>
- (instancetype)initWithId:(RAMDInt * _Nullable)id name:(NSString * _Nullable)name status:(NSString * _Nullable)status image:(NSString * _Nullable)image __attribute__((swift_name("init(id:name:status:image:)"))) __attribute__((objc_designated_initializer));
- (RAMDInt * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (RAMDResultResponse *)doCopyId:(RAMDInt * _Nullable)id name:(NSString * _Nullable)name status:(NSString * _Nullable)status image:(NSString * _Nullable)image __attribute__((swift_name("doCopy(id:name:status:image:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDInt * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable image __attribute__((swift_name("image")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResultResponse.Companion")))
@interface RAMDResultResponseCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<RAMDKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("CharacterUseCase")))
@protocol RAMDCharacterUseCase
@required
- (void)getCharactersPage:(int32_t)page success:(void (^)(RAMDCharacters *))success failure:(void (^)(RAMDKotlinThrowable *))failure __attribute__((swift_name("getCharacters(page:success:failure:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharacterUseCaseCompanion")))
@interface RAMDCharacterUseCaseCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("LocalDataSource")))
@protocol RAMDLocalDataSource
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalDataSourceCompanion")))
@interface RAMDLocalDataSourceCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("CharactersService")))
@protocol RAMDCharactersService
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharactersServiceCompanion")))
@interface RAMDCharactersServiceCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("ConfigDSL")))
@protocol RAMDConfigDSL
@required
- (void)restConfigurationBlock:(void (^)(id<RAMDNetConfig>))block __attribute__((swift_name("restConfiguration(block:)")));
- (void)sqlDriverBlock:(id<RAMDRuntimeSqlDriver> (^)(void))block __attribute__((swift_name("sqlDriver(block:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigurationException")))
@interface RAMDConfigurationException : RAMDKotlinRuntimeException
- (instancetype)initWithMess:(NSString *)mess __attribute__((swift_name("init(mess:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((swift_name("NetConfig")))
@protocol RAMDNetConfig
@required
@property NSString * _Nullable pathCharactersEp __attribute__((swift_name("pathCharactersEp")));
@property NSString * _Nullable url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Apollo_apiOperation")))
@protocol RAMDApollo_apiOperation
@required
- (RAMDOkioByteString *)composeRequestBody __attribute__((swift_name("composeRequestBody()")));
- (RAMDOkioByteString *)composeRequestBodyScalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(scalarTypeAdapters:)")));
- (id<RAMDApollo_apiOperationName>)name_ __attribute__((swift_name("name()")));
- (NSString *)operationId __attribute__((swift_name("operationId()")));
- (RAMDApollo_apiResponse<id> *)parseSource:(id<RAMDOkioBufferedSource>)source __attribute__((swift_name("parse(source:)")));
- (RAMDApollo_apiResponse<id> *)parseSource:(id<RAMDOkioBufferedSource>)source scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(source:scalarTypeAdapters:)")));
- (RAMDApollo_apiResponse<id> *)parseByteString:(RAMDOkioByteString *)byteString __attribute__((swift_name("parse(byteString:)")));
- (RAMDApollo_apiResponse<id> *)parseByteString:(RAMDOkioByteString *)byteString scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(byteString:scalarTypeAdapters:)")));
- (NSString *)queryDocument __attribute__((swift_name("queryDocument()")));
- (id<RAMDApollo_apiResponseFieldMapper>)responseFieldMapper __attribute__((swift_name("responseFieldMapper()")));
- (RAMDApollo_apiOperationVariables *)variables __attribute__((swift_name("variables()")));
- (id _Nullable)wrapDataData:(id<RAMDApollo_apiOperationData> _Nullable)data __attribute__((swift_name("wrapData(data:)")));
@end;

__attribute__((swift_name("Apollo_apiQuery")))
@protocol RAMDApollo_apiQuery <RAMDApollo_apiOperation>
@required
- (RAMDOkioByteString *)composeRequestBodyAutoPersistQueries:(BOOL)autoPersistQueries withQueryDocument:(BOOL)withQueryDocument scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(autoPersistQueries:withQueryDocument:scalarTypeAdapters:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery")))
@interface RAMDDataModelResponseQuery : RAMDBase <RAMDApollo_apiQuery>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (RAMDOkioByteString *)composeRequestBody __attribute__((swift_name("composeRequestBody()")));
- (RAMDOkioByteString *)composeRequestBodyScalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(scalarTypeAdapters:)")));
- (RAMDOkioByteString *)composeRequestBodyAutoPersistQueries:(BOOL)autoPersistQueries withQueryDocument:(BOOL)withQueryDocument scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(autoPersistQueries:withQueryDocument:scalarTypeAdapters:)")));
- (id<RAMDApollo_apiOperationName>)name_ __attribute__((swift_name("name()")));
- (NSString *)operationId __attribute__((swift_name("operationId()")));
- (RAMDApollo_apiResponse<RAMDDataModelResponseQueryData *> *)parseSource:(id<RAMDOkioBufferedSource>)source __attribute__((swift_name("parse(source:)")));
- (RAMDApollo_apiResponse<RAMDDataModelResponseQueryData *> *)parseSource:(id<RAMDOkioBufferedSource>)source scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(source:scalarTypeAdapters:)")));
- (RAMDApollo_apiResponse<RAMDDataModelResponseQueryData *> *)parseByteString:(RAMDOkioByteString *)byteString __attribute__((swift_name("parse(byteString:)")));
- (RAMDApollo_apiResponse<RAMDDataModelResponseQueryData *> *)parseByteString:(RAMDOkioByteString *)byteString scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(byteString:scalarTypeAdapters:)")));
- (NSString *)queryDocument __attribute__((swift_name("queryDocument()")));
- (id<RAMDApollo_apiResponseFieldMapper>)responseFieldMapper __attribute__((swift_name("responseFieldMapper()")));
- (RAMDApollo_apiOperationVariables *)variables __attribute__((swift_name("variables()")));
- (RAMDDataModelResponseQueryData * _Nullable)wrapDataData:(RAMDDataModelResponseQueryData * _Nullable)data __attribute__((swift_name("wrapData(data:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.Characters")))
@interface RAMDDataModelResponseQueryCharacters : RAMDBase
- (instancetype)initWith__typename:(NSString *)__typename results:(NSArray<id> * _Nullable)results __attribute__((swift_name("init(__typename:results:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSArray<id> * _Nullable)component2 __attribute__((swift_name("component2()")));
- (RAMDDataModelResponseQueryCharacters *)doCopy__typename:(NSString *)__typename results:(NSArray<id> * _Nullable)results __attribute__((swift_name("doCopy(__typename:results:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<RAMDApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *__typename __attribute__((swift_name("__typename")));
@property (readonly) NSArray<id> * _Nullable results __attribute__((swift_name("results")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.CharactersCompanion")))
@interface RAMDDataModelResponseQueryCharactersCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<RAMDApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (RAMDDataModelResponseQueryCharacters *)invokeReader:(id<RAMDApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.Companion")))
@interface RAMDDataModelResponseQueryCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) id<RAMDApollo_apiOperationName> OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@property (readonly) NSString *QUERY_DOCUMENT __attribute__((swift_name("QUERY_DOCUMENT")));
@end;

__attribute__((swift_name("Apollo_apiOperationData")))
@protocol RAMDApollo_apiOperationData
@required
- (id<RAMDApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.Data")))
@interface RAMDDataModelResponseQueryData : RAMDBase <RAMDApollo_apiOperationData>
- (instancetype)initWithCharacters:(RAMDDataModelResponseQueryCharacters * _Nullable)characters __attribute__((swift_name("init(characters:)"))) __attribute__((objc_designated_initializer));
- (RAMDDataModelResponseQueryCharacters * _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDDataModelResponseQueryData *)doCopyCharacters:(RAMDDataModelResponseQueryCharacters * _Nullable)characters __attribute__((swift_name("doCopy(characters:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<RAMDApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDDataModelResponseQueryCharacters * _Nullable characters __attribute__((swift_name("characters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.DataCompanion")))
@interface RAMDDataModelResponseQueryDataCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<RAMDApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (RAMDDataModelResponseQueryData *)invokeReader:(id<RAMDApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.Result")))
@interface RAMDDataModelResponseQueryResult : RAMDBase
- (instancetype)initWith__typename:(NSString *)__typename id:(NSString * _Nullable)id name:(NSString * _Nullable)name image:(NSString * _Nullable)image status:(NSString * _Nullable)status __attribute__((swift_name("init(__typename:id:name:image:status:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (RAMDDataModelResponseQueryResult *)doCopy__typename:(NSString *)__typename id:(NSString * _Nullable)id name:(NSString * _Nullable)name image:(NSString * _Nullable)image status:(NSString * _Nullable)status __attribute__((swift_name("doCopy(__typename:id:name:image:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<RAMDApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *__typename __attribute__((swift_name("__typename")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable image __attribute__((swift_name("image")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelResponseQuery.ResultCompanion")))
@interface RAMDDataModelResponseQueryResultCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<RAMDApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (RAMDDataModelResponseQueryResult *)invokeReader:(id<RAMDApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((swift_name("Apollo_apiScalarType")))
@protocol RAMDApollo_apiScalarType
@required
- (NSString *)className __attribute__((swift_name("className()")));
- (NSString *)typeName __attribute__((swift_name("typeName()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomType")))
@interface RAMDCustomType : RAMDKotlinEnum<RAMDCustomType *> <RAMDApollo_apiScalarType>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDCustomType *id __attribute__((swift_name("id")));
- (int32_t)compareToOther:(RAMDCustomType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((unavailable("can't be imported")))
__attribute__((swift_name("AndThen")))
@interface RAMDAndThen : NSObject
@end;

__attribute__((swift_name("Kind")))
@protocol RAMDKind
@required
@end;

__attribute__((swift_name("Either")))
@interface RAMDEither<__covariant A, __covariant B> : RAMDBase <RAMDKind>
- (id _Nullable)foldIfLeft:(id _Nullable (^)(A _Nullable))ifLeft ifRight:(id _Nullable (^)(B _Nullable))ifRight __attribute__((swift_name("fold(ifLeft:ifRight:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial rightOperation:(id _Nullable (^)(id _Nullable, B _Nullable))rightOperation __attribute__((swift_name("foldLeft(initial:rightOperation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial rightOperation:(RAMDEval<id> *(^)(B _Nullable, RAMDEval<id> *))rightOperation __attribute__((swift_name("foldRight(initial:rightOperation:)")));
- (BOOL)isLeft __attribute__((swift_name("isLeft()")));
- (BOOL)isRight __attribute__((swift_name("isRight()")));
- (RAMDEither<A, id> *)mapF:(id _Nullable (^)(B _Nullable))f __attribute__((swift_name("map(f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherCompanion")))
@interface RAMDEitherCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDEither<id, id> *)condTest:(BOOL)test ifTrue:(id _Nullable (^)(void))ifTrue ifFalse:(id _Nullable (^)(void))ifFalse __attribute__((swift_name("cond(test:ifTrue:ifFalse:)")));
- (RAMDEither<id, RAMDKotlinNothing *> *)leftLeft:(id _Nullable)left __attribute__((swift_name("left(left:)")));
- (RAMDEither<RAMDKotlinNothing *, id> *)rightRight:(id _Nullable)right __attribute__((swift_name("right(right:)")));
- (RAMDEither<id, id> *)tailRecMA:(id _Nullable)a f:(id<RAMDKind> (^)(id _Nullable))f __attribute__((swift_name("tailRecM(a:f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherLeft")))
@interface RAMDEitherLeft<__covariant A> : RAMDEither<A, RAMDKotlinNothing *>
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDEitherLeft<A> *)doCopyA:(A _Nullable)a __attribute__((swift_name("doCopy(a:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (id _Nullable)foldIfLeft:(id _Nullable (^)(A _Nullable))ifLeft ifRight:(id _Nullable (^)(RAMDKotlinNothing *))ifRight __attribute__((swift_name("fold(ifLeft:ifRight:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial rightOperation:(id _Nullable (^)(id _Nullable, RAMDKotlinNothing *))rightOperation __attribute__((swift_name("foldLeft(initial:rightOperation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial rightOperation:(RAMDEval<id> *(^)(RAMDKotlinNothing *, RAMDEval<id> *))rightOperation __attribute__((swift_name("foldRight(initial:rightOperation:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (RAMDEither<A, id> *)mapF:(id _Nullable (^)(RAMDKotlinNothing *))f __attribute__((swift_name("map(f:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) A _Nullable a __attribute__((swift_name("a")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherLeftCompanion")))
@interface RAMDEitherLeftCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDEither<id, RAMDKotlinNothing *> *)invokeA:(id _Nullable)a __attribute__((swift_name("invoke(a:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherRight")))
@interface RAMDEitherRight<__covariant B> : RAMDEither<RAMDKotlinNothing *, B>
- (B _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDEitherRight<B> *)doCopyB:(B _Nullable)b __attribute__((swift_name("doCopy(b:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (id _Nullable)foldIfLeft:(id _Nullable (^)(RAMDKotlinNothing *))ifLeft ifRight:(id _Nullable (^)(B _Nullable))ifRight __attribute__((swift_name("fold(ifLeft:ifRight:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (RAMDEither<RAMDKotlinNothing *, id> *)mapF:(id _Nullable (^)(B _Nullable))f __attribute__((swift_name("map(f:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) B _Nullable b __attribute__((swift_name("b")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherRightCompanion")))
@interface RAMDEitherRightCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDEither<RAMDKotlinNothing *, id> *)invokeB:(id _Nullable)b __attribute__((swift_name("invoke(b:)")));
@end;

__attribute__((swift_name("Eval")))
@interface RAMDEval<__covariant A> : RAMDBase <RAMDKind>
- (RAMDEval<id> *)coflatMapF:(id _Nullable (^)(id<RAMDKind>))f __attribute__((swift_name("coflatMap(f:)")));
- (A _Nullable)extract __attribute__((swift_name("extract()")));
- (RAMDEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalAlways")))
@interface RAMDEvalAlways<__covariant A> : RAMDEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (RAMDEvalAlways<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (RAMDEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalCompanion")))
@interface RAMDEvalCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDEvalAlways<id> *)alwaysF:(id _Nullable (^)(void))f __attribute__((swift_name("always(f:)")));
- (RAMDEval<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (RAMDEvalLater<id> *)laterF:(id _Nullable (^)(void))f __attribute__((swift_name("later(f:)")));
- (RAMDEvalNow<id> *)nowA:(id _Nullable)a __attribute__((swift_name("now(a:)")));
@property (readonly) RAMDEval<RAMDBoolean *> *False __attribute__((swift_name("False")));
@property (readonly) RAMDEval<RAMDInt *> *One __attribute__((swift_name("One")));
@property (readonly) RAMDEval<RAMDBoolean *> *True __attribute__((swift_name("True")));
@property (readonly) RAMDEval<RAMDKotlinUnit *> *Unit __attribute__((swift_name("Unit")));
@property (readonly) RAMDEval<RAMDInt *> *Zero __attribute__((swift_name("Zero")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalLater")))
@interface RAMDEvalLater<__covariant A> : RAMDEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (RAMDEvalLater<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (RAMDEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@property (readonly, getter=value_) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalNow")))
@interface RAMDEvalNow<__covariant A> : RAMDEval<A>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDEvalNow<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (RAMDEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@property (readonly, getter=value_) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForAndThen")))
@interface RAMDForAndThen : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForAndThen.Companion")))
@interface RAMDForAndThenCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForEither")))
@interface RAMDForEither : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForEither.Companion")))
@interface RAMDForEitherCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForEval")))
@interface RAMDForEval : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForEval.Companion")))
@interface RAMDForEvalCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForOption")))
@interface RAMDForOption : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForOption.Companion")))
@interface RAMDForOptionCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForTry")))
@interface RAMDForTry : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForTry.Companion")))
@interface RAMDForTryCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("MpTry")))
@interface RAMDMpTry<__covariant A> : RAMDBase <RAMDKind>
- (RAMDMpTry<id> *)apFf:(id<RAMDKind>)ff __attribute__((swift_name("ap(ff:)")));
- (BOOL)existsPredicate:(RAMDBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("exists(predicate:)")));
- (RAMDMpTry<RAMDKotlinThrowable *> *)failed __attribute__((swift_name("failed()")));
- (RAMDMpTry<A> *)filterP:(RAMDBoolean *(^)(A _Nullable))p __attribute__((swift_name("filter(p:)")));
- (RAMDMpTry<id> *)flatMapF:(id<RAMDKind> (^)(A _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfFailure:(id _Nullable (^)(RAMDKotlinThrowable *))ifFailure ifSuccess:(id _Nullable (^)(A _Nullable))ifSuccess __attribute__((swift_name("fold(ifFailure:ifSuccess:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, A _Nullable))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial operation:(RAMDEval<id> *(^)(A _Nullable, RAMDEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (RAMDMpTry<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
- (RAMDEither<RAMDKotlinThrowable *, A> *)toEither __attribute__((swift_name("toEither()")));
- (RAMDEither<id, A> *)toEitherOnLeft:(id _Nullable (^)(RAMDKotlinThrowable *))onLeft __attribute__((swift_name("toEither(onLeft:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryCompanion")))
@interface RAMDMpTryCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDMpTry<id> *)invokeF:(id _Nullable (^)(void))f __attribute__((swift_name("invoke(f:)")));
- (RAMDMpTry<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (RAMDMpTry<id> *)raiseE:(RAMDKotlinThrowable *)e __attribute__((swift_name("raise(e:)")));
- (RAMDMpTry<id> *)tailRecMA:(id _Nullable)a f:(id<RAMDKind> (^)(id _Nullable))f __attribute__((swift_name("tailRecM(a:f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryFailure")))
@interface RAMDMpTryFailure : RAMDMpTry<RAMDKotlinNothing *>
- (instancetype)initWithException:(RAMDKotlinThrowable *)exception __attribute__((swift_name("init(exception:)"))) __attribute__((objc_designated_initializer));
- (RAMDKotlinThrowable *)component1 __attribute__((swift_name("component1()")));
- (RAMDMpTryFailure *)doCopyException:(RAMDKotlinThrowable *)exception __attribute__((swift_name("doCopy(exception:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)existsPredicate:(RAMDBoolean *(^)(RAMDKotlinNothing *))predicate __attribute__((swift_name("exists(predicate:)")));
- (RAMDMpTry<RAMDKotlinNothing *> *)filterP:(RAMDBoolean *(^)(RAMDKotlinNothing *))p __attribute__((swift_name("filter(p:)")));
- (RAMDMpTry<id> *)flatMapF:(id<RAMDKind> (^)(RAMDKotlinNothing *))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfFailure:(id _Nullable (^)(RAMDKotlinThrowable *))ifFailure ifSuccess:(id _Nullable (^)(RAMDKotlinNothing *))ifSuccess __attribute__((swift_name("fold(ifFailure:ifSuccess:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, RAMDKotlinNothing *))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial operation:(RAMDEval<id> *(^)(RAMDKotlinNothing *, RAMDEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (RAMDMpTry<id> *)mapF:(id _Nullable (^)(RAMDKotlinNothing *))f __attribute__((swift_name("map(f:)")));
- (RAMDEither<RAMDKotlinThrowable *, RAMDKotlinNothing *> *)toEither __attribute__((swift_name("toEither()")));
- (RAMDEither<id, RAMDKotlinNothing *> *)toEitherOnLeft:(id _Nullable (^)(RAMDKotlinThrowable *))onLeft __attribute__((swift_name("toEither(onLeft:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDKotlinThrowable *exception __attribute__((swift_name("exception")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTrySuccess")))
@interface RAMDMpTrySuccess<__covariant A> : RAMDMpTry<A>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDMpTrySuccess<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Option")))
@interface RAMDOption<__covariant A> : RAMDBase <RAMDKind>
- (RAMDOption<id> *)andValue:(RAMDOption<id> *)value __attribute__((swift_name("and(value:)")));
- (RAMDOption<id> *)apFf:(id<RAMDKind>)ff __attribute__((swift_name("ap(ff:)")));
- (BOOL)existsPredicate:(RAMDBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("exists(predicate:)")));
- (RAMDOption<A> *)filterPredicate:(RAMDBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("filter(predicate:)")));
- (RAMDOption<A> *)filterNotPredicate:(RAMDBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("filterNot(predicate:)")));
- (RAMDOption<id> *)flatMapF:(id<RAMDKind> (^)(A _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfEmpty:(id _Nullable (^)(void))ifEmpty ifSome:(id _Nullable (^)(A _Nullable))ifSome __attribute__((swift_name("fold(ifEmpty:ifSome:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, A _Nullable))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial operation:(RAMDEval<id> *(^)(A _Nullable, RAMDEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (BOOL)forallP:(RAMDBoolean *(^)(A _Nullable))p __attribute__((swift_name("forall(p:)")));
- (BOOL)isDefined __attribute__((swift_name("isDefined()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (RAMDOption<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
- (RAMDOption<id> *)mapFilterF:(RAMDOption<id> *(^)(A _Nullable))f __attribute__((swift_name("mapFilter(f:)")));
- (RAMDOption<id> *)mapNotNullF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("mapNotNull(f:)")));
- (BOOL)nonEmpty __attribute__((swift_name("nonEmpty()")));
- (A _Nullable)orNull __attribute__((swift_name("orNull()")));
- (RAMDEither<id, A> *)toEitherIfEmpty:(id _Nullable (^)(void))ifEmpty __attribute__((swift_name("toEither(ifEmpty:)")));
- (NSArray<id> *)toList __attribute__((swift_name("toList()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("None")))
@interface RAMDNone : RAMDOption<RAMDKotlinNothing *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)none __attribute__((swift_name("init()")));
- (BOOL)existsPredicate:(RAMDBoolean *(^)(RAMDKotlinNothing *))predicate __attribute__((swift_name("exists(predicate:)")));
- (RAMDOption<RAMDKotlinNothing *> *)filterPredicate:(RAMDBoolean *(^)(RAMDKotlinNothing *))predicate __attribute__((swift_name("filter(predicate:)")));
- (RAMDOption<RAMDKotlinNothing *> *)filterNotPredicate:(RAMDBoolean *(^)(RAMDKotlinNothing *))predicate __attribute__((swift_name("filterNot(predicate:)")));
- (RAMDOption<id> *)flatMapF:(id<RAMDKind> (^)(RAMDKotlinNothing *))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfEmpty:(id _Nullable (^)(void))ifEmpty ifSome:(id _Nullable (^)(RAMDKotlinNothing *))ifSome __attribute__((swift_name("fold(ifEmpty:ifSome:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, RAMDKotlinNothing *))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial operation:(RAMDEval<id> *(^)(RAMDKotlinNothing *, RAMDEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (BOOL)forallP:(RAMDBoolean *(^)(RAMDKotlinNothing *))p __attribute__((swift_name("forall(p:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (RAMDOption<id> *)mapF:(id _Nullable (^)(RAMDKotlinNothing *))f __attribute__((swift_name("map(f:)")));
- (RAMDOption<id> *)mapFilterF:(RAMDOption<id> *(^)(RAMDKotlinNothing *))f __attribute__((swift_name("mapFilter(f:)")));
- (RAMDOption<id> *)mapNotNullF:(id _Nullable (^)(RAMDKotlinNothing *))f __attribute__((swift_name("mapNotNull(f:)")));
- (RAMDKotlinNothing * _Nullable)orNull __attribute__((swift_name("orNull()")));
- (RAMDEither<id, RAMDKotlinNothing *> *)toEitherIfEmpty:(id _Nullable (^)(void))ifEmpty __attribute__((swift_name("toEither(ifEmpty:)")));
- (NSArray<RAMDKotlinNothing *> *)toList __attribute__((swift_name("toList()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OptionCompanion")))
@interface RAMDOptionCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDOption<id> *)empty __attribute__((swift_name("empty()")));
- (RAMDOption<id> *)fromNullableA:(id _Nullable)a __attribute__((swift_name("fromNullable(a:)")));
- (RAMDOption<id> *)invokeA:(id _Nullable)a __attribute__((swift_name("invoke(a:)")));
- (RAMDOption<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (RAMDOption<id> *)tailRecMA:(id _Nullable)a f:(id<RAMDKind> (^)(id _Nullable))f __attribute__((swift_name("tailRecM(a:f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Some")))
@interface RAMDSome<__covariant T> : RAMDOption<T>
- (instancetype)initWithT:(T _Nullable)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer));
- (T _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDSome<T> *)doCopyT:(T _Nullable)t __attribute__((swift_name("doCopy(t:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)existsPredicate:(RAMDBoolean *(^)(T _Nullable))predicate __attribute__((swift_name("exists(predicate:)")));
- (RAMDOption<T> *)filterPredicate:(RAMDBoolean *(^)(T _Nullable))predicate __attribute__((swift_name("filter(predicate:)")));
- (RAMDOption<T> *)filterNotPredicate:(RAMDBoolean *(^)(T _Nullable))predicate __attribute__((swift_name("filterNot(predicate:)")));
- (RAMDOption<id> *)flatMapF:(id<RAMDKind> (^)(T _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfEmpty:(id _Nullable (^)(void))ifEmpty ifSome:(id _Nullable (^)(T _Nullable))ifSome __attribute__((swift_name("fold(ifEmpty:ifSome:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, T _Nullable))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (RAMDEval<id> *)foldRightInitial:(RAMDEval<id> *)initial operation:(RAMDEval<id> *(^)(T _Nullable, RAMDEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (BOOL)forallP:(RAMDBoolean *(^)(T _Nullable))p __attribute__((swift_name("forall(p:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (RAMDOption<id> *)mapF:(id _Nullable (^)(T _Nullable))f __attribute__((swift_name("map(f:)")));
- (RAMDOption<id> *)mapFilterF:(RAMDOption<id> *(^)(T _Nullable))f __attribute__((swift_name("mapFilter(f:)")));
- (RAMDOption<id> *)mapNotNullF:(id _Nullable (^)(T _Nullable))f __attribute__((swift_name("mapNotNull(f:)")));
- (T _Nullable)orNull __attribute__((swift_name("orNull()")));
- (RAMDEither<id, T> *)toEitherIfEmpty:(id _Nullable (^)(void))ifEmpty __attribute__((swift_name("toEither(ifEmpty:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T _Nullable t __attribute__((swift_name("t")));
@end;

__attribute__((swift_name("TryException")))
@interface RAMDTryException : RAMDKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TryException.PredicateException")))
@interface RAMDTryExceptionPredicateException : RAMDTryException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (RAMDTryExceptionPredicateException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TryException.UnsupportedOperationException")))
@interface RAMDTryExceptionUnsupportedOperationException : RAMDTryException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (RAMDTryExceptionUnsupportedOperationException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Deriving")))
@interface RAMDDeriving<A> : RAMDBase <RAMDKind>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (RAMDDeriving<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (RAMDDeriving<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DerivingCompanion")))
@interface RAMDDerivingCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (RAMDDeriving<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (RAMDDeriving<id> *)tailRecMA:(id _Nullable)a f:(id<RAMDKind> (^)(id _Nullable))f __attribute__((swift_name("tailRecM(a:f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForDeriving")))
@interface RAMDForDeriving : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForDeriving.Companion")))
@interface RAMDForDerivingCompanion : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

@interface RAMDMapperManagerCompanion (Extensions)
- (id<RAMDMapperManager>)createCharactersServiceArgs:(NSDictionary<id<RAMDKotlinKClass>, id<RAMDKotlinSuspendFunction1>> *)args argsList:(NSDictionary<id<RAMDKotlinKClass>, id<RAMDKotlinSuspendFunction1>> *)argsList __attribute__((swift_name("createCharactersService(args:argsList:)")));
@end;

@interface RAMDDataModelResponseQueryResult (Extensions)
- (RAMDCharacter *)toCharacter __attribute__((swift_name("toCharacter()")));
@end;

@interface RAMDResultResponse (Extensions)
- (RAMDCharacter *)toCharacter __attribute__((swift_name("toCharacter()")));
@end;

@interface RAMDDataModelResponseQueryCharacters (Extensions)
- (RAMDCharacters *)toCharacters __attribute__((swift_name("toCharacters()")));
@end;

@interface RAMDCharactersResponse (Extensions)
- (RAMDCharacters *)toCharacters __attribute__((swift_name("toCharacters()")));
@end;

@interface RAMDCharactersServiceCompanion (Extensions)
- (id<RAMDCharactersService>)createCharactersServiceLogger:(id<RAMDLogger>)logger __attribute__((swift_name("createCharactersService(logger:)")));
@end;

@interface RAMDKotlinThrowable (Extensions)
- (RAMDMpTry<id> *)failure __attribute__((swift_name("failure()")));
@end;

@interface RAMDOption (Extensions)
- (id _Nullable)getOrElseDefault:(id _Nullable (^)(void))default_ __attribute__((swift_name("getOrElse(default:)")));
- (RAMDOption<id> *)selectF:(id<RAMDKind>)f __attribute__((swift_name("select(f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ActualObjKt")))
@interface RAMDActualObjKt : RAMDBase
+ (int64_t)expectedTimestamp __attribute__((swift_name("expectedTimestamp()")));
+ (id<RAMDRuntimeSqlDriver>)getSqlDriver __attribute__((swift_name("getSqlDriver()")));
@property (class, readonly) id<RAMDKtor_client_coreHttpClientEngine> clientEngine __attribute__((swift_name("clientEngine")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UtilsKt")))
@interface RAMDUtilsKt : RAMDBase
+ (RAMDKotlinPair<NSArray<RAMDKotlinThrowable *> *, NSArray<id> *> *)toPair:(NSArray<RAMDMpTry<id> *> *)receiver __attribute__((swift_name("toPair(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigBuilderKt")))
@interface RAMDConfigBuilderKt : RAMDBase
+ (void)configureLibraryUrlServer:(NSString *)urlServer pathCharactersEp:(NSString *)pathCharactersEp __attribute__((swift_name("configureLibrary(urlServer:pathCharactersEp:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceKt")))
@interface RAMDRemoteDataSourceKt : RAMDBase
+ (id<RAMDRemoteDataSource>)createApi __attribute__((swift_name("createApi()")));
+ (id<RAMDRemoteDataSource>)createApiClientHttpEngine:(id<RAMDKtor_client_coreHttpClientEngine>)clientHttpEngine __attribute__((swift_name("createApi(clientHttpEngine:)")));
+ (id<RAMDRemoteDataSource>)createRemoteDataSourceKtor __attribute__((swift_name("createRemoteDataSourceKtor()")));
+ (id<RAMDRemoteDataSource>)createRemoteDataSourceKtorClientHttpEngine:(id<RAMDKtor_client_coreHttpClientEngine>)clientHttpEngine __attribute__((swift_name("createRemoteDataSourceKtor(clientHttpEngine:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApolloUtilKt")))
@interface RAMDApolloUtilKt : RAMDBase
+ (RAMDApollo_runtime_kotlinApolloClient *)createApolloClient __attribute__((swift_name("createApolloClient()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceGraphQlKt")))
@interface RAMDRemoteDataSourceGraphQlKt : RAMDBase
+ (id<RAMDRemoteDataSource>)createRemoteDataSourceGraphQl __attribute__((swift_name("createRemoteDataSourceGraphQl()")));
+ (id<RAMDRemoteDataSource>)createRemoteDataSourceGraphQlClient:(RAMDApollo_runtime_kotlinApolloClient *)client __attribute__((swift_name("createRemoteDataSourceGraphQl(client:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Serialization_ExtKt")))
@interface RAMDSerialization_ExtKt : RAMDBase
+ (id<RAMDKotlinSuspendFunction1>)mapperBasicT:(id<RAMDKotlinx_serialization_runtimeKSerializer>)t __attribute__((swift_name("mapperBasic(t:)")));
+ (id<RAMDKotlinSuspendFunction1>)mapperListT:(id<RAMDKotlinx_serialization_runtimeKSerializer>)t __attribute__((swift_name("mapperList(t:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataModelKt")))
@interface RAMDDataModelKt : RAMDBase
+ (RAMDInt * _Nullable)toIntOrNull:(NSString * _Nullable)receiver __attribute__((swift_name("toIntOrNull(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharacterUseCaseKt")))
@interface RAMDCharacterUseCaseKt : RAMDBase
+ (id<RAMDCharacterUseCase>)createCharacterUseCase __attribute__((swift_name("createCharacterUseCase()")));
+ (id<RAMDCharacterUseCase>)createCharacterUseCaseDs:(id<RAMDCharactersService>)ds __attribute__((swift_name("createCharacterUseCase(ds:)")));
+ (id<RAMDCharacterUseCase>)createCharacterUseCaseGraphQl __attribute__((swift_name("createCharacterUseCaseGraphQl()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DbKt")))
@interface RAMDDbKt : RAMDBase
+ (id<RAMDRickAndMortyDb>)createDb __attribute__((swift_name("createDb()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalDataSourceKt")))
@interface RAMDLocalDataSourceKt : RAMDBase
+ (id<RAMDLocalDataSource>)createLocalDataSource __attribute__((swift_name("createLocalDataSource()")));
+ (id<RAMDLocalDataSource>)createLocalDataSourceDb:(id<RAMDRickAndMortyDb>)db __attribute__((swift_name("createLocalDataSource(db:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DbDataModelKt")))
@interface RAMDDbDataModelKt : RAMDBase
+ (RAMDCharacter *)toCharacter:(id<RAMDCharacterDbModel>)receiver __attribute__((swift_name("toCharacter(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharactersServiceKt")))
@interface RAMDCharactersServiceKt : RAMDBase
+ (id<RAMDCharactersService>)createCharactersRepoMpWithOptionalLogger:(id<RAMDLogger>)logger __attribute__((swift_name("createCharactersRepoMpWithOptional(logger:)")));
+ (id<RAMDCharactersService>)createCharactersService __attribute__((swift_name("createCharactersService()")));
+ (id<RAMDCharactersService>)createCharactersServiceRemoteDs:(id<RAMDRemoteDataSource>)remoteDs __attribute__((swift_name("createCharactersService(remoteDs:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigDSLKt")))
@interface RAMDConfigDSLKt : RAMDBase
+ (id<RAMDConfigDSL>)configureBlock:(void (^)(id<RAMDConfigDSL>))block __attribute__((swift_name("configure(block:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PredefKt")))
@interface RAMDPredefKt : RAMDBase
+ (id _Nullable)identityA:(id _Nullable)a __attribute__((swift_name("identity(a:)")));
+ (id _Nullable (^)(id _Nullable))andThen:(id _Nullable (^)(id _Nullable))receiver g:(id _Nullable (^)(id _Nullable))g __attribute__((swift_name("andThen(_:g:)")));
+ (id _Nullable (^)(id _Nullable))compose:(id _Nullable (^)(id _Nullable))receiver f:(id _Nullable (^)(id _Nullable))f __attribute__((swift_name("compose(_:f:)")));
+ (id _Nullable (^(^)(id _Nullable))(id _Nullable))curry:(id _Nullable (^)(id _Nullable, id _Nullable))receiver __attribute__((swift_name("curry(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EitherKt")))
@interface RAMDEitherKt : RAMDBase
+ (RAMDEither<id, RAMDKotlinNothing *> *)LeftLeft:(id _Nullable)left __attribute__((swift_name("Left(left:)")));
+ (RAMDEither<RAMDKotlinNothing *, id> *)RightRight:(id _Nullable)right __attribute__((swift_name("Right(right:)")));
+ (RAMDEither<id, id> *)ap:(id<RAMDKind>)receiver ff:(id<RAMDKind>)ff __attribute__((swift_name("ap(_:ff:)")));
+ (RAMDEither<id, id> *)combineK:(id<RAMDKind>)receiver y:(id<RAMDKind>)y __attribute__((swift_name("combineK(_:y:)")));
+ (BOOL)contains:(id<RAMDKind>)receiver elem:(id _Nullable)elem __attribute__((swift_name("contains(_:elem:)")));
+ (RAMDEither<id, id> *)filterOrElse:(id<RAMDKind>)receiver predicate:(RAMDBoolean *(^)(id _Nullable))predicate default:(id _Nullable (^)(void))default_ __attribute__((swift_name("filterOrElse(_:predicate:default:)")));
+ (RAMDEither<id, id> *)filterOrOther:(id<RAMDKind>)receiver predicate:(RAMDBoolean *(^)(id _Nullable))predicate default:(id _Nullable (^)(id _Nullable))default_ __attribute__((swift_name("filterOrOther(_:predicate:default:)")));
+ (RAMDEither<id, id> *)fix:(id<RAMDKind>)receiver __attribute__((swift_name("fix(_:)")));
+ (RAMDEither<id, id> *)flatMap:(id<RAMDKind>)receiver f:(RAMDEither<id, id> *(^)(id _Nullable))f __attribute__((swift_name("flatMap(_:f:)")));
+ (id _Nullable)getOrElse:(id<RAMDKind>)receiver default:(id _Nullable (^)(void))default_ __attribute__((swift_name("getOrElse(_:default:)")));
+ (id _Nullable)getOrHandle:(id<RAMDKind>)receiver default:(id _Nullable (^)(id _Nullable))default_ __attribute__((swift_name("getOrHandle(_:default:)")));
+ (RAMDEither<id, id> *)handleErrorWith:(id<RAMDKind>)receiver f:(id<RAMDKind> (^)(id _Nullable))f __attribute__((swift_name("handleErrorWith(_:f:)")));
+ (RAMDEither<id, RAMDKotlinNothing *> *)left:(id _Nullable)receiver __attribute__((swift_name("left(_:)")));
+ (RAMDEither<id, id> *)leftIfNull:(id<RAMDKind>)receiver default:(id _Nullable (^)(void))default_ __attribute__((swift_name("leftIfNull(_:default:)")));
+ (id _Nullable)orNull:(id<RAMDKind>)receiver __attribute__((swift_name("orNull(_:)")));
+ (RAMDEither<RAMDKotlinNothing *, id> *)right:(id _Nullable)receiver __attribute__((swift_name("right(_:)")));
+ (RAMDEither<id, id> *)rightIfNotNull:(id _Nullable)receiver default:(id _Nullable (^)(void))default_ __attribute__((swift_name("rightIfNotNull(_:default:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryKt")))
@interface RAMDMpTryKt : RAMDBase
+ (id _Nullable)identityA_:(id _Nullable)a __attribute__((swift_name("identity(a_:)")));
+ (RAMDMpTry<id> *)fix_:(id<RAMDKind>)receiver __attribute__((swift_name("fix(__:)")));
+ (RAMDMpTry<id> *)flatten:(id<RAMDKind>)receiver __attribute__((swift_name("flatten(_:)")));
+ (id _Nullable)getOrDefault:(id<RAMDKind>)receiver default:(id _Nullable (^)(void))default_ __attribute__((swift_name("getOrDefault(_:default:)")));
+ (id _Nullable)getOrElse:(id<RAMDKind>)receiver default_:(id _Nullable (^)(RAMDKotlinThrowable *))default_ __attribute__((swift_name("getOrElse(_:default_:)")));
+ (RAMDMpTry<id> *)orElse:(id<RAMDKind>)receiver f:(id<RAMDKind> (^)(void))f __attribute__((swift_name("orElse(_:f:)")));
+ (id _Nullable)orNull_:(id<RAMDKind>)receiver __attribute__((swift_name("orNull(__:)")));
+ (RAMDMpTry<id> *)recover:(id<RAMDKind>)receiver f:(id _Nullable (^)(RAMDKotlinThrowable *))f __attribute__((swift_name("recover(_:f:)")));
+ (RAMDMpTry<id> *)recoverWith:(id<RAMDKind>)receiver f:(id<RAMDKind> (^)(RAMDKotlinThrowable *))f __attribute__((swift_name("recoverWith(_:f:)")));
+ (RAMDMpTry<id> *)rescue:(id<RAMDKind>)receiver f:(id<RAMDKind> (^)(RAMDKotlinThrowable *))f __attribute__((swift_name("rescue(_:f:)")));
+ (RAMDMpTry<id> *)success:(id _Nullable)receiver __attribute__((swift_name("success(_:)")));
+ (RAMDMpTry<id> *)try_:(id _Nullable (^)(void))receiver __attribute__((swift_name("try_(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OptionKt")))
@interface RAMDOptionKt : RAMDBase
+ (RAMDOption<id> *)none __attribute__((swift_name("none()")));
+ (RAMDOption<id> *)elementAtOrNone:(id)receiver index:(int32_t)index __attribute__((swift_name("elementAtOrNone(_:index:)")));
+ (RAMDOption<id> *)firstOrNone:(id)receiver __attribute__((swift_name("firstOrNone(_:)")));
+ (RAMDOption<id> *)firstOrNone:(id)receiver predicate:(RAMDBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("firstOrNone(_:predicate:)")));
+ (RAMDOption<id> *)fix__:(id<RAMDKind>)receiver __attribute__((swift_name("fix(___:)")));
+ (RAMDOption<id> *)lastOrNone:(id)receiver __attribute__((swift_name("lastOrNone(_:)")));
+ (RAMDOption<id> *)lastOrNone:(id)receiver predicate:(RAMDBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("lastOrNone(_:predicate:)")));
+ (RAMDOption<id> *)maybe:(BOOL)receiver f:(id _Nullable (^)(void))f __attribute__((swift_name("maybe(_:f:)")));
+ (RAMDOption<id> *)or:(id<RAMDKind>)receiver value:(RAMDOption<id> *)value __attribute__((swift_name("or(_:value:)")));
+ (RAMDOption<id> *)orElse:(id<RAMDKind>)receiver alternative:(RAMDOption<id> *(^)(void))alternative __attribute__((swift_name("orElse(_:alternative:)")));
+ (RAMDOption<id> *)singleOrNone:(id)receiver __attribute__((swift_name("singleOrNone(_:)")));
+ (RAMDOption<id> *)singleOrNone:(id)receiver predicate:(RAMDBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("singleOrNone(_:predicate:)")));
+ (RAMDOption<id> *)some:(id _Nullable)receiver __attribute__((swift_name("some(_:)")));
+ (RAMDOption<id> *)toOption:(id _Nullable)receiver __attribute__((swift_name("toOption(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AndThenKt")))
@interface RAMDAndThenKt : RAMDBase
+ (id _Nullable (^)(id _Nullable))fix___:(id<RAMDKind>)receiver __attribute__((swift_name("fix(____:)")));
+ (id _Nullable)invoke:(id<RAMDKind>)receiver a:(id _Nullable)a __attribute__((swift_name("invoke(_:a:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalKt")))
@interface RAMDEvalKt : RAMDBase
+ (RAMDEval<id> *)fix____:(id<RAMDKind>)receiver __attribute__((swift_name("fix(_____:)")));
+ (id _Nullable)value:(id<RAMDKind>)receiver __attribute__((swift_name("value(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DerivingKindsKt")))
@interface RAMDDerivingKindsKt : RAMDBase
+ (RAMDDeriving<id> *)fix_____:(id<RAMDKind>)receiver __attribute__((swift_name("fix(______:)")));
@end;

__attribute__((swift_name("RuntimeQuery")))
@interface RAMDRuntimeQuery<__covariant RowType> : RAMDBase
- (instancetype)initWithQueries:(NSMutableArray<RAMDRuntimeQuery<id> *> *)queries mapper:(RowType (^)(id<RAMDRuntimeSqlCursor>))mapper __attribute__((swift_name("init(queries:mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<RAMDRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (id<RAMDRuntimeSqlCursor>)execute __attribute__((swift_name("execute()")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
- (void)notifyDataChanged __attribute__((swift_name("notifyDataChanged()")));
- (void)removeListenerListener:(id<RAMDRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@property (readonly) RowType (^mapper)(id<RAMDRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end;

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface RAMDRuntimeTransacterTransaction : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
- (void)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(RAMDRuntimeTransacterTransaction *))body __attribute__((swift_name("transaction(body:)")));
@property (readonly) RAMDRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end;

__attribute__((swift_name("RuntimeCloseable")))
@protocol RAMDRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol RAMDRuntimeSqlDriver <RAMDRuntimeCloseable>
@required
- (RAMDRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (void)executeIdentifier:(RAMDInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<RAMDRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<RAMDRuntimeSqlCursor>)executeQueryIdentifier:(RAMDInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<RAMDRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:parameters:binders:)")));
- (RAMDRuntimeTransacterTransaction *)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface RAMDKotlinArray<T> : RAMDBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(RAMDInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<RAMDKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerializationStrategy")))
@protocol RAMDKotlinx_serialization_runtimeSerializationStrategy
@required
- (void)serializeEncoder:(id<RAMDKotlinx_serialization_runtimeEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<RAMDKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDeserializationStrategy")))
@protocol RAMDKotlinx_serialization_runtimeDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<RAMDKotlinx_serialization_runtimeDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (id _Nullable)patchDecoder:(id<RAMDKotlinx_serialization_runtimeDecoder>)decoder old:(id _Nullable)old __attribute__((swift_name("patch(decoder:old:)")));
@property (readonly) id<RAMDKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeKSerializer")))
@protocol RAMDKotlinx_serialization_runtimeKSerializer <RAMDKotlinx_serialization_runtimeSerializationStrategy, RAMDKotlinx_serialization_runtimeDeserializationStrategy>
@required
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol RAMDKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol RAMDKotlinSuspendFunction1 <RAMDKotlinFunction>
@required
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol RAMDKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol RAMDKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol RAMDKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol RAMDKotlinKClass <RAMDKotlinKDeclarationContainer, RAMDKotlinKAnnotatedElement, RAMDKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinApolloClient")))
@interface RAMDApollo_runtime_kotlinApolloClient : RAMDBase
- (instancetype)initWithNetworkTransport:(id<RAMDApollo_runtime_kotlinNetworkTransport>)networkTransport scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters interceptors:(NSArray<id<RAMDApollo_runtime_kotlinApolloRequestInterceptor>> *)interceptors executionContext:(id<RAMDApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(networkTransport:scalarTypeAdapters:interceptors:executionContext:)"))) __attribute__((objc_designated_initializer));
- (id<RAMDApollo_runtime_kotlinApolloMutationCall>)mutateMutation:(id<RAMDApollo_apiMutation>)mutation __attribute__((swift_name("mutate(mutation:)")));
- (id<RAMDApollo_runtime_kotlinApolloQueryCall>)queryQuery:(id<RAMDApollo_apiQuery>)query __attribute__((swift_name("query(query:)")));
@end;

__attribute__((swift_name("OkioByteString")))
@interface RAMDOkioByteString : RAMDBase <RAMDKotlinComparable>
- (NSString *)base64 __attribute__((swift_name("base64()")));
- (NSString *)base64Url __attribute__((swift_name("base64Url()")));
- (int32_t)compareToOther:(RAMDOkioByteString *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)endsWithSuffix:(RAMDKotlinByteArray *)suffix __attribute__((swift_name("endsWith(suffix:)")));
- (BOOL)endsWithSuffix_:(RAMDOkioByteString *)suffix __attribute__((swift_name("endsWith(suffix_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)hex __attribute__((swift_name("hex()")));
- (int32_t)indexOfOther:(RAMDKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex:)")));
- (int32_t)indexOfOther:(RAMDOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex_:)")));
- (int32_t)lastIndexOfOther:(RAMDKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex:)")));
- (int32_t)lastIndexOfOther:(RAMDOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex_:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(RAMDKotlinByteArray *)other otherOffset:(int32_t)otherOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(RAMDOkioByteString *)other otherOffset:(int32_t)otherOffset byteCount_:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount_:)")));
- (BOOL)startsWithPrefix:(RAMDKotlinByteArray *)prefix __attribute__((swift_name("startsWith(prefix:)")));
- (BOOL)startsWithPrefix_:(RAMDOkioByteString *)prefix __attribute__((swift_name("startsWith(prefix_:)")));
- (RAMDOkioByteString *)substringBeginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("substring(beginIndex:endIndex:)")));
- (RAMDOkioByteString *)toAsciiLowercase __attribute__((swift_name("toAsciiLowercase()")));
- (RAMDOkioByteString *)toAsciiUppercase __attribute__((swift_name("toAsciiUppercase()")));
- (RAMDKotlinByteArray *)toByteArray __attribute__((swift_name("toByteArray()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSString *)utf8 __attribute__((swift_name("utf8()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiScalarTypeAdapters")))
@interface RAMDApollo_apiScalarTypeAdapters : RAMDBase
- (instancetype)initWithCustomAdapters:(NSDictionary<id<RAMDApollo_apiScalarType>, id<RAMDApollo_apiCustomTypeAdapter>> *)customAdapters __attribute__((swift_name("init(customAdapters:)"))) __attribute__((objc_designated_initializer));
- (id<RAMDApollo_apiCustomTypeAdapter>)adapterForScalarType:(id<RAMDApollo_apiScalarType>)scalarType __attribute__((swift_name("adapterFor(scalarType:)")));
@property (readonly) NSDictionary<id<RAMDApollo_apiScalarType>, id<RAMDApollo_apiCustomTypeAdapter>> *customAdapters __attribute__((swift_name("customAdapters")));
@end;

__attribute__((swift_name("Apollo_apiOperationName")))
@protocol RAMDApollo_apiOperationName
@required
- (NSString *)name_ __attribute__((swift_name("name()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponse")))
@interface RAMDApollo_apiResponse<T> : RAMDBase
- (instancetype)initWithBuilder:(RAMDApollo_apiResponseBuilder<T> *)builder __attribute__((swift_name("init(builder:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithOperation:(id<RAMDApollo_apiOperation>)operation data:(T _Nullable)data errors:(NSArray<RAMDApollo_apiError *> * _Nullable)errors dependentKeys:(NSSet<NSString *> *)dependentKeys fromCache:(BOOL)fromCache extensions:(NSDictionary<NSString *, id> *)extensions executionContext:(id<RAMDApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(operation:data:errors:dependentKeys:fromCache:extensions:executionContext:)"))) __attribute__((objc_designated_initializer));
- (id<RAMDApollo_apiOperation>)component1 __attribute__((swift_name("component1()")));
- (T _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSArray<RAMDApollo_apiError *> * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSSet<NSString *> *)component4 __attribute__((swift_name("component4()")));
- (BOOL)component5 __attribute__((swift_name("component5()")));
- (NSDictionary<NSString *, id> *)component6 __attribute__((swift_name("component6()")));
- (id<RAMDApollo_apiExecutionContext>)component7 __attribute__((swift_name("component7()")));
- (RAMDApollo_apiResponse<T> *)doCopyOperation:(id<RAMDApollo_apiOperation>)operation data:(T _Nullable)data errors:(NSArray<RAMDApollo_apiError *> * _Nullable)errors dependentKeys:(NSSet<NSString *> *)dependentKeys fromCache:(BOOL)fromCache extensions:(NSDictionary<NSString *, id> *)extensions executionContext:(id<RAMDApollo_apiExecutionContext>)executionContext __attribute__((swift_name("doCopy(operation:data:errors:dependentKeys:fromCache:extensions:executionContext:)")));
- (T _Nullable)data __attribute__((swift_name("data()"))) __attribute__((deprecated("Use property instead")));
- (NSSet<NSString *> *)dependentKeys __attribute__((swift_name("dependentKeys()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSArray<RAMDApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors()"))) __attribute__((deprecated("Use property instead")));
- (NSDictionary<NSString *, id> *)extensions __attribute__((swift_name("extensions()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)fromCache __attribute__((swift_name("fromCache()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)hasErrors __attribute__((swift_name("hasErrors()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<RAMDApollo_apiOperation>)operation __attribute__((swift_name("operation()"))) __attribute__((deprecated("Use property instead")));
- (RAMDApollo_apiResponseBuilder<T> *)toBuilder __attribute__((swift_name("toBuilder()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=data_) T _Nullable data __attribute__((swift_name("data")));
@property (readonly, getter=dependentKeys_) NSSet<NSString *> *dependentKeys __attribute__((swift_name("dependentKeys")));
@property (readonly, getter=errors_) NSArray<RAMDApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) id<RAMDApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly, getter=extensions_) NSDictionary<NSString *, id> *extensions __attribute__((swift_name("extensions")));
@property (readonly, getter=fromCache_) BOOL fromCache __attribute__((swift_name("fromCache")));
@property (readonly, getter=operation_) id<RAMDApollo_apiOperation> operation __attribute__((swift_name("operation")));
@end;

__attribute__((swift_name("OkioSource")))
@protocol RAMDOkioSource
@required
- (void)close __attribute__((swift_name("close()")));
- (int64_t)readSink:(RAMDOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("read(sink:byteCount:)")));
- (RAMDOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
@end;

__attribute__((swift_name("OkioBufferedSource")))
@protocol RAMDOkioBufferedSource <RAMDOkioSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(RAMDOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(RAMDOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(RAMDOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(RAMDOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<RAMDOkioBufferedSource>)peek __attribute__((swift_name("peek()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(RAMDOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(RAMDOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(RAMDKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(RAMDKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readAllSink:(id<RAMDOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (RAMDKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (RAMDKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (RAMDOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (RAMDOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(RAMDKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(RAMDOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<RAMDOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
@property (readonly) RAMDOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end;

__attribute__((swift_name("Apollo_apiResponseFieldMapper")))
@protocol RAMDApollo_apiResponseFieldMapper
@required
- (id _Nullable)mapResponseReader:(id<RAMDApollo_apiResponseReader>)responseReader __attribute__((swift_name("map(responseReader:)")));
@end;

__attribute__((swift_name("Apollo_apiOperationVariables")))
@interface RAMDApollo_apiOperationVariables : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)marshal __attribute__((swift_name("marshal()")));
- (NSString *)marshalScalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("marshal(scalarTypeAdapters:)")));
- (id<RAMDApollo_apiInputFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSDictionary<NSString *, id> *)valueMap __attribute__((swift_name("valueMap()")));
@end;

__attribute__((swift_name("Apollo_apiResponseFieldMarshaller")))
@protocol RAMDApollo_apiResponseFieldMarshaller
@required
- (void)marshalWriter:(id<RAMDApollo_apiResponseWriter>)writer __attribute__((swift_name("marshal(writer:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseReader")))
@protocol RAMDApollo_apiResponseReader
@required
- (RAMDBoolean * _Nullable)readBooleanField:(RAMDApollo_apiResponseField *)field __attribute__((swift_name("readBoolean(field:)")));
- (id _Nullable)readCustomTypeField:(RAMDApollo_apiResponseFieldCustomTypeField *)field __attribute__((swift_name("readCustomType(field:)")));
- (RAMDDouble * _Nullable)readDoubleField:(RAMDApollo_apiResponseField *)field __attribute__((swift_name("readDouble(field:)")));
- (id _Nullable)readFragmentField:(RAMDApollo_apiResponseField *)field block:(id (^)(id<RAMDApollo_apiResponseReader>))block __attribute__((swift_name("readFragment(field:block:)")));
- (id _Nullable)readFragmentField:(RAMDApollo_apiResponseField *)field objectReader:(id<RAMDApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readFragment(field:objectReader:)")));
- (RAMDInt * _Nullable)readIntField:(RAMDApollo_apiResponseField *)field __attribute__((swift_name("readInt(field:)")));
- (NSArray<id> * _Nullable)readListField:(RAMDApollo_apiResponseField *)field block:(id (^)(id<RAMDApollo_apiResponseReaderListItemReader>))block __attribute__((swift_name("readList(field:block:)")));
- (NSArray<id> * _Nullable)readListField:(RAMDApollo_apiResponseField *)field listReader:(id<RAMDApollo_apiResponseReaderListReader>)listReader __attribute__((swift_name("readList(field:listReader:)")));
- (RAMDLong * _Nullable)readLongField:(RAMDApollo_apiResponseField *)field __attribute__((swift_name("readLong(field:)")));
- (id _Nullable)readObjectField:(RAMDApollo_apiResponseField *)field block:(id (^)(id<RAMDApollo_apiResponseReader>))block __attribute__((swift_name("readObject(field:block:)")));
- (id _Nullable)readObjectField:(RAMDApollo_apiResponseField *)field objectReader:(id<RAMDApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readObject(field:objectReader:)")));
- (NSString * _Nullable)readStringField:(RAMDApollo_apiResponseField *)field __attribute__((swift_name("readString(field:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface RAMDKotlinNothing : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface RAMDKotlinUnit : RAMDBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol RAMDKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<RAMDKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol RAMDKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol RAMDKtor_client_coreHttpClientEngine <RAMDKotlinx_coroutines_coreCoroutineScope, RAMDKtor_ioCloseable>
@required
- (void)installClient:(RAMDKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) RAMDKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) RAMDKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<RAMDKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface RAMDKotlinPair<__covariant A, __covariant B> : RAMDBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (B _Nullable)component2 __attribute__((swift_name("component2()")));
- (RAMDKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@end;

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol RAMDRuntimeSqlCursor <RAMDRuntimeCloseable>
@required
- (RAMDKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (RAMDDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (RAMDLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (BOOL)next __attribute__((swift_name("next()")));
@end;

__attribute__((swift_name("RuntimeQueryListener")))
@protocol RAMDRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end;

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol RAMDRuntimeSqlPreparedStatement
@required
- (void)bindBytesIndex:(int32_t)index value:(RAMDKotlinByteArray * _Nullable)value __attribute__((swift_name("bindBytes(index:value:)")));
- (void)bindDoubleIndex:(int32_t)index value:(RAMDDouble * _Nullable)value __attribute__((swift_name("bindDouble(index:value:)")));
- (void)bindLongIndex:(int32_t)index value:(RAMDLong * _Nullable)value __attribute__((swift_name("bindLong(index:value:)")));
- (void)bindStringIndex:(int32_t)index value:(NSString * _Nullable)value __attribute__((swift_name("bindString(index:value:)")));
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol RAMDKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next_ __attribute__((swift_name("next_()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeEncoder")))
@protocol RAMDKotlinx_serialization_runtimeEncoder
@required
- (id<RAMDKotlinx_serialization_runtimeCompositeEncoder>)beginCollectionDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize typeSerializers:(RAMDKotlinArray<id<RAMDKotlinx_serialization_runtimeKSerializer>> *)typeSerializers __attribute__((swift_name("beginCollection(descriptor:collectionSize:typeSerializers:)")));
- (id<RAMDKotlinx_serialization_runtimeCompositeEncoder>)beginStructureDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeSerializers:(RAMDKotlinArray<id<RAMDKotlinx_serialization_runtimeKSerializer>> *)typeSerializers __attribute__((swift_name("beginStructure(descriptor:typeSerializers:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<RAMDKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<RAMDKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
- (void)encodeUnit __attribute__((swift_name("encodeUnit()")));
@property (readonly) id<RAMDKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialDescriptor")))
@protocol RAMDKotlinx_serialization_runtimeSerialDescriptor
@required
- (NSArray<id<RAMDKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (NSArray<id<RAMDKotlinAnnotation>> *)getEntityAnnotations __attribute__((swift_name("getEntityAnnotations()"))) __attribute__((deprecated("Deprecated in the favour of 'annotations' property")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<RAMDKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) RAMDKotlinx_serialization_runtimeSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *name __attribute__((swift_name("name"))) __attribute__((unavailable("name property deprecated in the favour of serialName")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDecoder")))
@protocol RAMDKotlinx_serialization_runtimeDecoder
@required
- (id<RAMDKotlinx_serialization_runtimeCompositeDecoder>)beginStructureDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeParams:(RAMDKotlinArray<id<RAMDKotlinx_serialization_runtimeKSerializer>> *)typeParams __attribute__((swift_name("beginStructure(descriptor:typeParams:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (RAMDKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
- (void)decodeUnit __attribute__((swift_name("decodeUnit()")));
- (id _Nullable)updateNullableSerializableValueDeserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableValue(deserializer:old:)")));
- (id _Nullable)updateSerializableValueDeserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableValue(deserializer:old:)")));
@property (readonly) id<RAMDKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) RAMDKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinNetworkTransport")))
@protocol RAMDApollo_runtime_kotlinNetworkTransport
@required
- (id<RAMDKotlinx_coroutines_coreFlow>)executeRequest:(RAMDApollo_runtime_kotlinGraphQLRequest *)request __attribute__((swift_name("execute(request:)")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloRequestInterceptor")))
@protocol RAMDApollo_runtime_kotlinApolloRequestInterceptor
@required
- (id<RAMDKotlinx_coroutines_coreFlow>)interceptRequest:(RAMDApollo_runtime_kotlinApolloRequest<id> *)request interceptorChain:(id<RAMDApollo_runtime_kotlinApolloInterceptorChain>)interceptorChain __attribute__((swift_name("intercept(request:interceptorChain:)")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContext")))
@protocol RAMDApollo_apiExecutionContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<RAMDApollo_apiExecutionContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<RAMDApollo_apiExecutionContextElement> _Nullable)getKey:(id<RAMDApollo_apiExecutionContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<RAMDApollo_apiExecutionContext>)minusKeyKey:(id<RAMDApollo_apiExecutionContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<RAMDApollo_apiExecutionContext>)plusContext:(id<RAMDApollo_apiExecutionContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloCall")))
@protocol RAMDApollo_runtime_kotlinApolloCall
@required
- (id<RAMDKotlinx_coroutines_coreFlow>)execute __attribute__((swift_name("execute()")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloMutationCall")))
@protocol RAMDApollo_runtime_kotlinApolloMutationCall <RAMDApollo_runtime_kotlinApolloCall>
@required
@end;

__attribute__((swift_name("Apollo_apiMutation")))
@protocol RAMDApollo_apiMutation <RAMDApollo_apiOperation>
@required
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloQueryCall")))
@protocol RAMDApollo_runtime_kotlinApolloQueryCall <RAMDApollo_runtime_kotlinApolloCall>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface RAMDKotlinByteArray : RAMDBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(RAMDByte *(^)(RAMDInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (RAMDKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Apollo_apiCustomTypeAdapter")))
@protocol RAMDApollo_apiCustomTypeAdapter
@required
- (id _Nullable)decodeValue:(RAMDApollo_apiCustomTypeValue<id> *)value __attribute__((swift_name("decode(value:)")));
- (RAMDApollo_apiCustomTypeValue<id> *)encodeValue:(id _Nullable)value __attribute__((swift_name("encode(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseBuilder")))
@interface RAMDApollo_apiResponseBuilder<T> : RAMDBase
- (RAMDApollo_apiResponse<T> *)build __attribute__((swift_name("build()")));
- (RAMDApollo_apiResponseBuilder<T> *)dataData:(T _Nullable)data __attribute__((swift_name("data(data:)")));
- (RAMDApollo_apiResponseBuilder<T> *)dependentKeysDependentKeys:(NSSet<NSString *> * _Nullable)dependentKeys __attribute__((swift_name("dependentKeys(dependentKeys:)")));
- (RAMDApollo_apiResponseBuilder<T> *)errorsErrors:(NSArray<RAMDApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors(errors:)")));
- (RAMDApollo_apiResponseBuilder<T> *)executionContextExecutionContext:(id<RAMDApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));
- (RAMDApollo_apiResponseBuilder<T> *)extensionsExtensions:(NSDictionary<NSString *, id> * _Nullable)extensions __attribute__((swift_name("extensions(extensions:)")));
- (RAMDApollo_apiResponseBuilder<T> *)fromCacheFromCache:(BOOL)fromCache __attribute__((swift_name("fromCache(fromCache:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError")))
@interface RAMDApollo_apiError : RAMDBase
- (instancetype)initWithMessage:(NSString *)message locations:(NSArray<RAMDApollo_apiErrorLocation *> *)locations customAttributes:(NSDictionary<NSString *, id> *)customAttributes __attribute__((swift_name("init(message:locations:customAttributes:)"))) __attribute__((objc_designated_initializer));
- (NSDictionary<NSString *, id> *)customAttributes __attribute__((swift_name("customAttributes()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSArray<RAMDApollo_apiErrorLocation *> *)locations __attribute__((swift_name("locations()"))) __attribute__((deprecated("Use property instead")));
- (NSString * _Nullable)message __attribute__((swift_name("message()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=customAttributes_) NSDictionary<NSString *, id> *customAttributes __attribute__((swift_name("customAttributes")));
@property (readonly, getter=locations_) NSArray<RAMDApollo_apiErrorLocation *> *locations __attribute__((swift_name("locations")));
@property (readonly, getter=message_) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("OkioSink")))
@protocol RAMDOkioSink
@required
- (void)close __attribute__((swift_name("close()")));
- (void)flush __attribute__((swift_name("flush()")));
- (RAMDOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (void)writeSource:(RAMDOkioBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end;

__attribute__((swift_name("OkioBufferedSink")))
@protocol RAMDOkioBufferedSink <RAMDOkioSink>
@required
- (id<RAMDOkioBufferedSink>)emit __attribute__((swift_name("emit()")));
- (id<RAMDOkioBufferedSink>)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (id<RAMDOkioBufferedSink>)writeSource:(RAMDKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (id<RAMDOkioBufferedSink>)writeSource:(RAMDKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (id<RAMDOkioBufferedSink>)writeByteString:(RAMDOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (id<RAMDOkioBufferedSink>)writeByteString:(RAMDOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (id<RAMDOkioBufferedSink>)writeSource:(id<RAMDOkioSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (int64_t)writeAllSource:(id<RAMDOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (id<RAMDOkioBufferedSink>)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (id<RAMDOkioBufferedSink>)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (id<RAMDOkioBufferedSink>)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (id<RAMDOkioBufferedSink>)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (id<RAMDOkioBufferedSink>)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (id<RAMDOkioBufferedSink>)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (id<RAMDOkioBufferedSink>)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (id<RAMDOkioBufferedSink>)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (id<RAMDOkioBufferedSink>)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (id<RAMDOkioBufferedSink>)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (id<RAMDOkioBufferedSink>)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (id<RAMDOkioBufferedSink>)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) RAMDOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer")))
@interface RAMDOkioBuffer : RAMDBase <RAMDOkioBufferedSource, RAMDOkioBufferedSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)completeSegmentByteCount __attribute__((swift_name("completeSegmentByteCount()")));
- (RAMDOkioBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (RAMDOkioBuffer *)doCopyToOut:(RAMDOkioBuffer *)out offset:(int64_t)offset __attribute__((swift_name("doCopyTo(out:offset:)")));
- (RAMDOkioBuffer *)doCopyToOut:(RAMDOkioBuffer *)out offset:(int64_t)offset byteCount:(int64_t)byteCount __attribute__((swift_name("doCopyTo(out:offset:byteCount:)")));
- (RAMDOkioBuffer *)emit __attribute__((swift_name("emit()")));
- (RAMDOkioBuffer *)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPos:(int64_t)pos __attribute__((swift_name("get(pos:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(RAMDOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(RAMDOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(RAMDOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(RAMDOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<RAMDOkioBufferedSource>)peek __attribute__((swift_name("peek()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(RAMDOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(RAMDOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(RAMDKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(RAMDKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readSink:(RAMDOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("read(sink:byteCount:)")));
- (int64_t)readAllSink:(id<RAMDOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (RAMDKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (RAMDKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (RAMDOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (RAMDOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(RAMDKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(RAMDOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<RAMDOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (RAMDOkioByteString *)snapshot __attribute__((swift_name("snapshot()")));
- (RAMDOkioByteString *)snapshotByteCount:(int32_t)byteCount __attribute__((swift_name("snapshot(byteCount:)")));
- (RAMDOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (RAMDOkioBuffer *)writeSource:(RAMDKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (RAMDOkioBuffer *)writeSource:(RAMDKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (void)writeSource:(RAMDOkioBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (RAMDOkioBuffer *)writeByteString:(RAMDOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (RAMDOkioBuffer *)writeByteString:(RAMDOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (RAMDOkioBuffer *)writeSource:(id<RAMDOkioSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (int64_t)writeAllSource:(id<RAMDOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (RAMDOkioBuffer *)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (RAMDOkioBuffer *)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (RAMDOkioBuffer *)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (RAMDOkioBuffer *)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (RAMDOkioBuffer *)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (RAMDOkioBuffer *)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (RAMDOkioBuffer *)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (RAMDOkioBuffer *)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (RAMDOkioBuffer *)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (RAMDOkioBuffer *)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (RAMDOkioBuffer *)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (RAMDOkioBuffer *)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) RAMDOkioBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("OkioTimeout")))
@interface RAMDOkioTimeout : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldMarshaller")))
@protocol RAMDApollo_apiInputFieldMarshaller
@required
- (void)marshalWriter_:(id<RAMDApollo_apiInputFieldWriter>)writer __attribute__((swift_name("marshal(writer_:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriter")))
@protocol RAMDApollo_apiResponseWriter
@required
- (void)writeBooleanField:(RAMDApollo_apiResponseField *)field value:(RAMDBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(field:value:)")));
- (void)writeCustomField:(RAMDApollo_apiResponseFieldCustomTypeField *)field value:(id _Nullable)value __attribute__((swift_name("writeCustom(field:value:)")));
- (void)writeDoubleField:(RAMDApollo_apiResponseField *)field value:(RAMDDouble * _Nullable)value __attribute__((swift_name("writeDouble(field:value:)")));
- (void)writeFragmentMarshaller:(id<RAMDApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeFragment(marshaller:)")));
- (void)writeIntField:(RAMDApollo_apiResponseField *)field value:(RAMDInt * _Nullable)value __attribute__((swift_name("writeInt(field:value:)")));
- (void)writeListField:(RAMDApollo_apiResponseField *)field values:(NSArray<id> * _Nullable)values block:(void (^)(NSArray<id> * _Nullable, id<RAMDApollo_apiResponseWriterListItemWriter>))block __attribute__((swift_name("writeList(field:values:block:)")));
- (void)writeListField:(RAMDApollo_apiResponseField *)field values:(NSArray<id> * _Nullable)values listWriter:(id<RAMDApollo_apiResponseWriterListWriter>)listWriter __attribute__((swift_name("writeList(field:values:listWriter:)")));
- (void)writeLongField:(RAMDApollo_apiResponseField *)field value:(RAMDLong * _Nullable)value __attribute__((swift_name("writeLong(field:value:)")));
- (void)writeObjectField:(RAMDApollo_apiResponseField *)field marshaller:(id<RAMDApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(field:marshaller:)")));
- (void)writeStringField:(RAMDApollo_apiResponseField *)field value:(NSString * _Nullable)value __attribute__((swift_name("writeString(field:value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseField")))
@interface RAMDApollo_apiResponseField : RAMDBase
- (NSDictionary<NSString *, id> *)arguments __attribute__((swift_name("arguments()"))) __attribute__((deprecated("Use property instead")));
- (NSArray<RAMDApollo_apiResponseFieldCondition *> *)conditions __attribute__((swift_name("conditions()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSString *)fieldName __attribute__((swift_name("fieldName()"))) __attribute__((deprecated("Use property instead")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)optional __attribute__((swift_name("optional()"))) __attribute__((deprecated("Use property instead")));
- (id _Nullable)resolveArgumentName:(NSString *)name variables:(RAMDApollo_apiOperationVariables *)variables __attribute__((swift_name("resolveArgument(name:variables:)")));
- (NSString *)responseName __attribute__((swift_name("responseName()"))) __attribute__((deprecated("Use property instead")));
- (RAMDApollo_apiResponseFieldType *)type __attribute__((swift_name("type()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=arguments_) NSDictionary<NSString *, id> *arguments __attribute__((swift_name("arguments")));
@property (readonly, getter=conditions_) NSArray<RAMDApollo_apiResponseFieldCondition *> *conditions __attribute__((swift_name("conditions")));
@property (readonly, getter=fieldName_) NSString *fieldName __attribute__((swift_name("fieldName")));
@property (readonly, getter=optional_) BOOL optional __attribute__((swift_name("optional")));
@property (readonly, getter=responseName_) NSString *responseName __attribute__((swift_name("responseName")));
@property (readonly, getter=type_) RAMDApollo_apiResponseFieldType *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseField.CustomTypeField")))
@interface RAMDApollo_apiResponseFieldCustomTypeField : RAMDApollo_apiResponseField
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<RAMDApollo_apiScalarType>)scalarType __attribute__((swift_name("scalarType()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=scalarType_) id<RAMDApollo_apiScalarType> scalarType __attribute__((swift_name("scalarType")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderObjectReader")))
@protocol RAMDApollo_apiResponseReaderObjectReader
@required
- (id)readReader:(id<RAMDApollo_apiResponseReader>)reader __attribute__((swift_name("read(reader:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderListItemReader")))
@protocol RAMDApollo_apiResponseReaderListItemReader
@required
- (BOOL)readBoolean __attribute__((swift_name("readBoolean()")));
- (id)readCustomTypeScalarType:(id<RAMDApollo_apiScalarType>)scalarType __attribute__((swift_name("readCustomType(scalarType:)")));
- (double)readDouble __attribute__((swift_name("readDouble()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (NSArray<id> *)readListBlock:(id (^)(id<RAMDApollo_apiResponseReaderListItemReader>))block __attribute__((swift_name("readList(block:)")));
- (NSArray<id> *)readListListReader:(id<RAMDApollo_apiResponseReaderListReader>)listReader __attribute__((swift_name("readList(listReader:)")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (id)readObjectBlock:(id (^)(id<RAMDApollo_apiResponseReader>))block __attribute__((swift_name("readObject(block:)")));
- (id)readObjectObjectReader:(id<RAMDApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readObject(objectReader:)")));
- (NSString *)readString __attribute__((swift_name("readString()")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderListReader")))
@protocol RAMDApollo_apiResponseReaderListReader
@required
- (id)readReader_:(id<RAMDApollo_apiResponseReaderListItemReader>)reader __attribute__((swift_name("read(reader_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface RAMDKtor_client_coreHttpClient : RAMDBase <RAMDKotlinx_coroutines_coreCoroutineScope, RAMDKtor_ioCloseable>
- (instancetype)initWithEngine:(id<RAMDKtor_client_coreHttpClientEngine>)engine userConfig:(RAMDKtor_client_coreHttpClientConfig<RAMDKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (RAMDKtor_client_coreHttpClient *)configBlock:(void (^)(RAMDKtor_client_coreHttpClientConfig<RAMDKtor_client_coreHttpClientEngineConfig *> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<RAMDKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<RAMDKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<RAMDKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) RAMDKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher"))) __attribute__((unavailable("[dispatcher] is deprecated. Use coroutineContext instead.")));
@property (readonly) id<RAMDKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) RAMDKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) RAMDKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) RAMDKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) RAMDKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) RAMDKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface RAMDKtor_client_coreHttpClientEngineConfig : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property RAMDKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property (readonly) RAMDKotlinNothing *response __attribute__((swift_name("response"))) __attribute__((unavailable("Response config is deprecated. See [HttpPlainText] feature for charset configuration")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol RAMDKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation_:(id _Nullable (^)(id _Nullable, id<RAMDKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation_:)")));
- (id<RAMDKotlinCoroutineContextElement> _Nullable)getKey_:(id<RAMDKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key_:)")));
- (id<RAMDKotlinCoroutineContext>)minusKeyKey_:(id<RAMDKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key_:)")));
- (id<RAMDKotlinCoroutineContext>)plusContext_:(id<RAMDKotlinCoroutineContext>)context __attribute__((swift_name("plus(context_:)")));
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol RAMDKotlinCoroutineContextElement <RAMDKotlinCoroutineContext>
@required
@property (readonly) id<RAMDKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface RAMDKotlinAbstractCoroutineContextElement : RAMDBase <RAMDKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<RAMDKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<RAMDKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol RAMDKotlinContinuationInterceptor <RAMDKotlinCoroutineContextElement>
@required
- (id<RAMDKotlinContinuation>)interceptContinuationContinuation:(id<RAMDKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<RAMDKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface RAMDKotlinx_coroutines_coreCoroutineDispatcher : RAMDKotlinAbstractCoroutineContextElement <RAMDKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<RAMDKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)dispatchContext:(id<RAMDKotlinCoroutineContext>)context block:(id<RAMDKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<RAMDKotlinCoroutineContext>)context block:(id<RAMDKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<RAMDKotlinContinuation>)interceptContinuationContinuation:(id<RAMDKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<RAMDKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (RAMDKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(RAMDKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<RAMDKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol RAMDKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeEncoder")))
@protocol RAMDKotlinx_serialization_runtimeCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (void)encodeIntElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNonSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(id)value __attribute__((swift_name("encodeNonSerializableElement(descriptor:index:value:)"))) __attribute__((unavailable("This method is deprecated for removal. Please remove it from your implementation and delegate to default method instead")));
- (void)encodeNullableSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<RAMDKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<RAMDKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)encodeUnitElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) id<RAMDKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModule")))
@protocol RAMDKotlinx_serialization_runtimeSerialModule
@required
- (void)dumpToCollector:(id<RAMDKotlinx_serialization_runtimeSerialModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<RAMDKotlinx_serialization_runtimeKSerializer> _Nullable)getContextualKclass:(id<RAMDKotlinKClass>)kclass __attribute__((swift_name("getContextual(kclass:)")));
- (id<RAMDKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<RAMDKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<RAMDKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<RAMDKotlinKClass>)baseClass serializedClassName:(NSString *)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol RAMDKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialKind")))
@interface RAMDKotlinx_serialization_runtimeSerialKind : RAMDBase
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeDecoder")))
@protocol RAMDKotlinx_serialization_runtimeCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:)")));
- (int16_t)decodeShortElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)decodeUnitElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (id _Nullable)updateNullableSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableElement(descriptor:index:deserializer:old:)")));
- (id _Nullable)updateSerializableElementDescriptor:(id<RAMDKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<RAMDKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableElement(descriptor:index:deserializer:old:)")));
@property (readonly) id<RAMDKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) RAMDKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeUpdateMode")))
@interface RAMDKotlinx_serialization_runtimeUpdateMode : RAMDKotlinEnum<RAMDKotlinx_serialization_runtimeUpdateMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDKotlinx_serialization_runtimeUpdateMode *banned __attribute__((swift_name("banned")));
@property (class, readonly) RAMDKotlinx_serialization_runtimeUpdateMode *overwrite __attribute__((swift_name("overwrite")));
@property (class, readonly) RAMDKotlinx_serialization_runtimeUpdateMode *update __attribute__((swift_name("update")));
- (int32_t)compareToOther:(RAMDKotlinx_serialization_runtimeUpdateMode *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol RAMDKotlinx_coroutines_coreFlow
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinGraphQLRequest")))
@interface RAMDApollo_runtime_kotlinGraphQLRequest : RAMDBase
- (instancetype)initWithOperationName:(NSString *)operationName operationId:(NSString *)operationId document:(NSString *)document variables:(NSString *)variables extensions:(NSString *)extensions __attribute__((swift_name("init(operationName:operationId:document:variables:extensions:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *document __attribute__((swift_name("document")));
@property (readonly) NSString *extensions __attribute__((swift_name("extensions")));
@property (readonly) NSString *operationId __attribute__((swift_name("operationId")));
@property (readonly) NSString *operationName __attribute__((swift_name("operationName")));
@property (readonly) NSString *variables __attribute__((swift_name("variables")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinApolloRequest")))
@interface RAMDApollo_runtime_kotlinApolloRequest<T> : RAMDBase
- (instancetype)initWithOperation:(id<RAMDApollo_apiOperation>)operation scalarTypeAdapters:(RAMDApollo_apiScalarTypeAdapters *)scalarTypeAdapters executionContext:(id<RAMDApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(operation:scalarTypeAdapters:executionContext:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<RAMDApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<RAMDApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) RAMDApollo_apiScalarTypeAdapters *scalarTypeAdapters __attribute__((swift_name("scalarTypeAdapters")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloInterceptorChain")))
@protocol RAMDApollo_runtime_kotlinApolloInterceptorChain
@required
- (BOOL)canProceed __attribute__((swift_name("canProceed()")));
- (id<RAMDKotlinx_coroutines_coreFlow>)proceedRequest:(RAMDApollo_runtime_kotlinApolloRequest<id> *)request __attribute__((swift_name("proceed(request:)")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContextElement")))
@protocol RAMDApollo_apiExecutionContextElement <RAMDApollo_apiExecutionContext>
@required
@property (readonly) id<RAMDApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContextKey")))
@protocol RAMDApollo_apiExecutionContextKey
@required
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface RAMDKotlinByteIterator : RAMDBase <RAMDKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (RAMDByte *)next_ __attribute__((swift_name("next_()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((swift_name("Apollo_apiCustomTypeValue")))
@interface RAMDApollo_apiCustomTypeValue<T> : RAMDBase
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError.Location")))
@interface RAMDApollo_apiErrorLocation : RAMDBase
- (instancetype)initWithLine:(int64_t)line column:(int64_t)column __attribute__((swift_name("init(line:column:)"))) __attribute__((objc_designated_initializer));
- (int64_t)column __attribute__((swift_name("column()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int64_t)line __attribute__((swift_name("line()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=column_) int64_t column __attribute__((swift_name("column")));
@property (readonly, getter=line_) int64_t line __attribute__((swift_name("line")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriter")))
@protocol RAMDApollo_apiInputFieldWriter
@required
- (void)writeBooleanFieldName:(NSString *)fieldName value:(RAMDBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(fieldName:value:)")));
- (void)writeCustomFieldName:(NSString *)fieldName scalarType:(id<RAMDApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(fieldName:scalarType:value:)")));
- (void)writeDoubleFieldName:(NSString *)fieldName value:(RAMDDouble * _Nullable)value __attribute__((swift_name("writeDouble(fieldName:value:)")));
- (void)writeIntFieldName:(NSString *)fieldName value:(RAMDInt * _Nullable)value __attribute__((swift_name("writeInt(fieldName:value:)")));
- (void)writeListFieldName:(NSString *)fieldName block:(void (^)(id<RAMDApollo_apiInputFieldWriterListItemWriter>))block __attribute__((swift_name("writeList(fieldName:block:)")));
- (void)writeListFieldName:(NSString *)fieldName listWriter:(id<RAMDApollo_apiInputFieldWriterListWriter> _Nullable)listWriter __attribute__((swift_name("writeList(fieldName:listWriter:)")));
- (void)writeLongFieldName:(NSString *)fieldName value:(RAMDLong * _Nullable)value __attribute__((swift_name("writeLong(fieldName:value:)")));
- (void)writeMapFieldName:(NSString *)fieldName value:(NSDictionary<NSString *, id> * _Nullable)value __attribute__((swift_name("writeMap(fieldName:value:)")));
- (void)writeNumberFieldName:(NSString *)fieldName value:(id _Nullable)value __attribute__((swift_name("writeNumber(fieldName:value:)")));
- (void)writeObjectFieldName:(NSString *)fieldName marshaller:(id<RAMDApollo_apiInputFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(fieldName:marshaller:)")));
- (void)writeStringFieldName:(NSString *)fieldName value:(NSString * _Nullable)value __attribute__((swift_name("writeString(fieldName:value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriterListItemWriter")))
@protocol RAMDApollo_apiResponseWriterListItemWriter
@required
- (void)writeBooleanValue:(RAMDBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(value:)")));
- (void)writeCustomScalarType:(id<RAMDApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(scalarType:value:)")));
- (void)writeDoubleValue:(RAMDDouble * _Nullable)value __attribute__((swift_name("writeDouble(value:)")));
- (void)writeIntValue:(RAMDInt * _Nullable)value __attribute__((swift_name("writeInt(value:)")));
- (void)writeListItems:(NSArray<id> * _Nullable)items block:(void (^)(NSArray<id> * _Nullable, id<RAMDApollo_apiResponseWriterListItemWriter>))block __attribute__((swift_name("writeList(items:block:)")));
- (void)writeListItems:(NSArray<id> * _Nullable)items listWriter:(id<RAMDApollo_apiResponseWriterListWriter>)listWriter __attribute__((swift_name("writeList(items:listWriter:)")));
- (void)writeLongValue:(RAMDLong * _Nullable)value __attribute__((swift_name("writeLong(value:)")));
- (void)writeObjectMarshaller:(id<RAMDApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(marshaller:)")));
- (void)writeStringValue:(NSString * _Nullable)value __attribute__((swift_name("writeString(value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriterListWriter")))
@protocol RAMDApollo_apiResponseWriterListWriter
@required
- (void)writeItems:(NSArray<id> * _Nullable)items listItemWriter:(id<RAMDApollo_apiResponseWriterListItemWriter>)listItemWriter __attribute__((swift_name("write(items:listItemWriter:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseField.Condition")))
@interface RAMDApollo_apiResponseFieldCondition : RAMDBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseField.Type_")))
@interface RAMDApollo_apiResponseFieldType : RAMDKotlinEnum<RAMDApollo_apiResponseFieldType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDApollo_apiResponseFieldType *string __attribute__((swift_name("string")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *int_ __attribute__((swift_name("int_")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *long_ __attribute__((swift_name("long_")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *double_ __attribute__((swift_name("double_")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *boolean __attribute__((swift_name("boolean")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *enum_ __attribute__((swift_name("enum_")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *object __attribute__((swift_name("object")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *list __attribute__((swift_name("list")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *custom __attribute__((swift_name("custom")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *fragment __attribute__((swift_name("fragment")));
@property (class, readonly) RAMDApollo_apiResponseFieldType *fragments __attribute__((swift_name("fragments")));
- (int32_t)compareToOther:(RAMDApollo_apiResponseFieldType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface RAMDKtor_client_coreHttpClientConfig<T> : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (RAMDKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(RAMDKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installFeature:(id<RAMDKtor_client_coreHttpClientFeature>)feature configure:(void (^)(id))configure __attribute__((swift_name("install(feature:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(RAMDKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(RAMDKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol RAMDKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(RAMDKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey__:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key__:)")));
- (id _Nullable)getOrNullKey:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(RAMDKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<RAMDKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface RAMDKtor_utilsPipeline<TSubject, TContext> : RAMDBase
- (instancetype)initWithPhase:(RAMDKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<RAMDKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(RAMDKotlinArray<RAMDKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(RAMDKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));
- (void)insertPhaseAfterReference:(RAMDKtor_utilsPipelinePhase *)reference phase:(RAMDKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(RAMDKtor_utilsPipelinePhase *)reference phase:(RAMDKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(RAMDKtor_utilsPipelinePhase *)phase block:(id<RAMDKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (void)mergeFrom:(RAMDKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
@property (readonly) id<RAMDKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<RAMDKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface RAMDKtor_client_coreHttpReceivePipeline : RAMDKtor_utilsPipeline<RAMDKtor_client_coreHttpResponse *, RAMDKtor_client_coreHttpClientCall *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(RAMDKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<RAMDKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(RAMDKotlinArray<RAMDKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(RAMDKtor_utilsPipeline<RAMDKtor_client_coreHttpResponse *, RAMDKtor_client_coreHttpClientCall *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface RAMDKtor_client_coreHttpRequestPipeline : RAMDKtor_utilsPipeline<id, RAMDKtor_client_coreHttpRequestBuilder *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(RAMDKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<RAMDKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(RAMDKotlinArray<RAMDKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(RAMDKtor_utilsPipeline<id, RAMDKtor_client_coreHttpRequestBuilder *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface RAMDKtor_client_coreHttpResponsePipeline : RAMDKtor_utilsPipeline<RAMDKtor_client_coreHttpResponseContainer *, RAMDKtor_client_coreHttpClientCall *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(RAMDKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<RAMDKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(RAMDKotlinArray<RAMDKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(RAMDKtor_utilsPipeline<RAMDKtor_client_coreHttpResponseContainer *, RAMDKtor_client_coreHttpClientCall *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface RAMDKtor_client_coreHttpSendPipeline : RAMDKtor_utilsPipeline<id, RAMDKtor_client_coreHttpRequestBuilder *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(RAMDKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<RAMDKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(RAMDKotlinArray<RAMDKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(RAMDKtor_utilsPipeline<id, RAMDKtor_client_coreHttpRequestBuilder *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface RAMDKtor_client_coreProxyConfig : RAMDBase
- (instancetype)initWithUrl:(RAMDKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol RAMDKotlinCoroutineContextKey
@required
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol RAMDKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<RAMDKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol RAMDKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModuleCollector")))
@protocol RAMDKotlinx_serialization_runtimeSerialModuleCollector
@required
- (void)contextualKClass:(id<RAMDKotlinKClass>)kClass serializer:(id<RAMDKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<RAMDKotlinKClass>)baseClass actualClass:(id<RAMDKotlinKClass>)actualClass actualSerializer:(id<RAMDKotlinx_serialization_runtimeKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriterListItemWriter")))
@protocol RAMDApollo_apiInputFieldWriterListItemWriter
@required
- (void)writeBooleanValue:(RAMDBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(value:)")));
- (void)writeCustomScalarType:(id<RAMDApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(scalarType:value:)")));
- (void)writeDoubleValue:(RAMDDouble * _Nullable)value __attribute__((swift_name("writeDouble(value:)")));
- (void)writeIntValue:(RAMDInt * _Nullable)value __attribute__((swift_name("writeInt(value:)")));
- (void)writeListBlock:(void (^)(id<RAMDApollo_apiInputFieldWriterListItemWriter>))block __attribute__((swift_name("writeList(block:)")));
- (void)writeListListWriter:(id<RAMDApollo_apiInputFieldWriterListWriter> _Nullable)listWriter __attribute__((swift_name("writeList(listWriter:)")));
- (void)writeLongValue:(RAMDLong * _Nullable)value __attribute__((swift_name("writeLong(value:)")));
- (void)writeMapValue:(NSDictionary<NSString *, id> * _Nullable)value __attribute__((swift_name("writeMap(value:)")));
- (void)writeNumberValue:(id _Nullable)value __attribute__((swift_name("writeNumber(value:)")));
- (void)writeObjectMarshaller_:(id<RAMDApollo_apiInputFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(marshaller_:)")));
- (void)writeStringValue:(NSString * _Nullable)value __attribute__((swift_name("writeString(value:)")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriterListWriter")))
@protocol RAMDApollo_apiInputFieldWriterListWriter
@required
- (void)writeListItemWriter:(id<RAMDApollo_apiInputFieldWriterListItemWriter>)listItemWriter __attribute__((swift_name("write(listItemWriter:)")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientFeature")))
@protocol RAMDKtor_client_coreHttpClientFeature
@required
- (void)installFeature:(id)feature scope:(RAMDKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(feature:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) RAMDKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface RAMDKtor_utilsAttributeKey<T> : RAMDBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface RAMDKtor_utilsPipelinePhase : RAMDBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol RAMDKotlinSuspendFunction2 <RAMDKotlinFunction>
@required
@end;

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol RAMDKtor_httpHttpMessage
@required
@property (readonly) id<RAMDKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface RAMDKtor_client_coreHttpResponse : RAMDBase <RAMDKtor_httpHttpMessage, RAMDKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<RAMDKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) RAMDKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) RAMDKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) RAMDKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) RAMDKtor_httpHttpProtocolVersion *version_ __attribute__((swift_name("version_")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface RAMDKtor_client_coreHttpClientCall : RAMDBase <RAMDKotlinx_coroutines_coreCoroutineScope>
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<RAMDKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) RAMDKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<RAMDKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<RAMDKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property (readonly) RAMDKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol RAMDKtor_httpHttpMessageBuilder
@required
@property (readonly) RAMDKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface RAMDKtor_client_coreHttpRequestBuilder : RAMDBase <RAMDKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (RAMDKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<RAMDKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<RAMDKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<RAMDKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (RAMDKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(RAMDKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (RAMDKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(RAMDKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(RAMDKtor_httpURLBuilder *, RAMDKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<RAMDKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property (readonly) id<RAMDKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) RAMDKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property RAMDKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) RAMDKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface RAMDKtor_client_coreHttpResponseContainer : RAMDBase
- (instancetype)initWithExpectedType:(RAMDKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (RAMDKtor_client_coreTypeInfo *)component1 __attribute__((swift_name("component1()")));
- (id)component2 __attribute__((swift_name("component2()")));
- (RAMDKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(RAMDKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDKtor_client_coreTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface RAMDKtor_httpUrl : RAMDBase
- (instancetype)initWithProtocol:(RAMDKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<RAMDKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (RAMDKtor_httpURLProtocol *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (id<RAMDKtor_httpParameters>)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString * _Nullable)component8 __attribute__((swift_name("component8()")));
- (BOOL)component9 __attribute__((swift_name("component9()")));
- (RAMDKtor_httpUrl *)doCopyProtocol:(RAMDKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<RAMDKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("doCopy(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<RAMDKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) RAMDKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol RAMDKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<RAMDKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol RAMDKtor_httpHeaders <RAMDKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol RAMDKtor_ioByteReadChannel
@required
- (BOOL)cancelCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (void)readSessionConsumer:(void (^)(id<RAMDKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property RAMDKtor_ioByteOrder *readByteOrder __attribute__((swift_name("readByteOrder"))) __attribute__((unavailable("Setting byte order is no longer supported. Read/write in big endian and use reverseByteOrder() extensions.")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead"))) __attribute__((deprecated("Don't use byte count")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface RAMDKtor_utilsGMTDate : RAMDBase <RAMDKotlinComparable>
- (int32_t)compareToOther:(RAMDKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (RAMDKtor_utilsWeekDay *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (int32_t)component6 __attribute__((swift_name("component6()")));
- (RAMDKtor_utilsMonth *)component7 __attribute__((swift_name("component7()")));
- (int32_t)component8 __attribute__((swift_name("component8()")));
- (int64_t)component9 __attribute__((swift_name("component9()")));
- (RAMDKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(RAMDKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(RAMDKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) RAMDKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) RAMDKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface RAMDKtor_httpHttpStatusCode : RAMDBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (RAMDKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (RAMDKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=description_) NSString *description __attribute__((swift_name("description")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface RAMDKtor_httpHttpProtocolVersion : RAMDBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (RAMDKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol RAMDKtor_client_coreHttpRequest <RAMDKtor_httpHttpMessage, RAMDKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<RAMDKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) RAMDKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) RAMDKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) RAMDKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) RAMDKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@interface RAMDKtor_utilsStringValuesBuilder : RAMDBase
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<RAMDKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<RAMDKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<RAMDKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<RAMDKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property BOOL built __attribute__((swift_name("built")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@property (readonly) RAMDMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface RAMDKtor_httpHeadersBuilder : RAMDKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<RAMDKtor_httpHeaders>)build __attribute__((swift_name("build()")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface RAMDKtor_client_coreHttpRequestData : RAMDBase
- (instancetype)initWithUrl:(RAMDKtor_httpUrl *)url method:(RAMDKtor_httpHttpMethod *)method headers:(id<RAMDKtor_httpHeaders>)headers body:(RAMDKtor_httpOutgoingContent *)body executionContext:(id<RAMDKotlinx_coroutines_coreJob>)executionContext attributes:(id<RAMDKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<RAMDKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<RAMDKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) RAMDKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<RAMDKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<RAMDKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) RAMDKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) RAMDKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface RAMDKtor_httpURLBuilder : RAMDBase
- (instancetype)initWithProtocol:(RAMDKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password encodedPath:(NSString *)encodedPath parameters:(RAMDKtor_httpParametersBuilder *)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:encodedPath:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (RAMDKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (RAMDKtor_httpURLBuilder *)pathComponents:(RAMDKotlinArray<NSString *> *)components __attribute__((swift_name("path(components:)")));
- (RAMDKtor_httpURLBuilder *)pathComponents_:(NSArray<NSString *> *)components __attribute__((swift_name("path(components_:)")));
@property NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) RAMDKtor_httpParametersBuilder *parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property int32_t port __attribute__((swift_name("port")));
@property RAMDKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol RAMDKotlinx_coroutines_coreJob <RAMDKotlinCoroutineContextElement>
@required
- (id<RAMDKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<RAMDKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause_:(RAMDKotlinx_coroutines_coreCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));
- (RAMDKotlinx_coroutines_coreCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<RAMDKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(RAMDKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<RAMDKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(RAMDKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));
- (id<RAMDKotlinx_coroutines_coreJob>)plusOther_:(id<RAMDKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<RAMDKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<RAMDKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface RAMDKtor_httpHttpMethod : RAMDBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (RAMDKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreTypeInfo")))
@interface RAMDKtor_client_coreTypeInfo : RAMDBase
- (instancetype)initWithType:(id<RAMDKotlinKClass>)type reifiedType:(id<RAMDKtor_client_coreType>)reifiedType kotlinType:(id<RAMDKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (id<RAMDKotlinKClass>)component1 __attribute__((swift_name("component1()")));
- (id<RAMDKtor_client_coreType>)component2 __attribute__((swift_name("component2()")));
- (id<RAMDKotlinKType> _Nullable)component3 __attribute__((swift_name("component3()")));
- (RAMDKtor_client_coreTypeInfo *)doCopyType:(id<RAMDKotlinKClass>)type reifiedType:(id<RAMDKtor_client_coreType>)reifiedType kotlinType:(id<RAMDKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<RAMDKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<RAMDKtor_client_coreType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<RAMDKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface RAMDKtor_httpURLProtocol : RAMDBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (RAMDKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol RAMDKtor_httpParameters <RAMDKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol RAMDKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly, getter=value_) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol RAMDKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (RAMDKtor_ioIoBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteOrder")))
@interface RAMDKtor_ioByteOrder : RAMDKotlinEnum<RAMDKtor_ioByteOrder *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDKtor_ioByteOrder *bigEndian __attribute__((swift_name("bigEndian")));
@property (class, readonly) RAMDKtor_ioByteOrder *littleEndian __attribute__((swift_name("littleEndian")));
- (int32_t)compareToOther:(RAMDKtor_ioByteOrder *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface RAMDKtor_utilsWeekDay : RAMDKotlinEnum<RAMDKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) RAMDKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) RAMDKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) RAMDKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) RAMDKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) RAMDKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) RAMDKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
- (int32_t)compareToOther:(RAMDKtor_utilsWeekDay *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface RAMDKtor_utilsMonth : RAMDKotlinEnum<RAMDKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) RAMDKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) RAMDKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) RAMDKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) RAMDKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) RAMDKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) RAMDKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) RAMDKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) RAMDKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) RAMDKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) RAMDKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) RAMDKtor_utilsMonth *december __attribute__((swift_name("december")));
- (int32_t)compareToOther:(RAMDKtor_utilsMonth *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface RAMDKtor_httpOutgoingContent : RAMDBase
- (id _Nullable)getPropertyKey:(RAMDKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(RAMDKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
@property (readonly) RAMDLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) RAMDKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<RAMDKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) RAMDKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpParametersBuilder")))
@interface RAMDKtor_httpParametersBuilder : RAMDKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<RAMDKtor_httpParameters>)build __attribute__((swift_name("build()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol RAMDKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol RAMDKotlinx_coroutines_coreChildHandle <RAMDKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(RAMDKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol RAMDKotlinx_coroutines_coreChildJob <RAMDKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<RAMDKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end;

__attribute__((swift_name("KotlinIllegalStateException")))
@interface RAMDKotlinIllegalStateException : RAMDKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCancellationException")))
@interface RAMDKotlinx_coroutines_coreCancellationException : RAMDKotlinIllegalStateException
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCause:(RAMDKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinSequence")))
@protocol RAMDKotlinSequence
@required
- (id<RAMDKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol RAMDKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<RAMDKotlinx_coroutines_coreSelectInstance>)select block:(id<RAMDKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end;

__attribute__((swift_name("Ktor_client_coreType")))
@protocol RAMDKtor_client_coreType
@required
@end;

__attribute__((swift_name("KotlinKType")))
@protocol RAMDKotlinKType
@required
@property (readonly, getter=arguments_) NSArray<RAMDKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) id<RAMDKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end;

__attribute__((swift_name("Ktor_ioBuffer")))
@interface RAMDKtor_ioBuffer : RAMDBase
- (instancetype)initWithMemory:(RAMDKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (int32_t)discardCount:(int32_t)count __attribute__((swift_name("discard(count:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (int64_t)discardCount_:(int64_t)count __attribute__((swift_name("discard(count_:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (RAMDKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)duplicateToCopy:(RAMDKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property id _Nullable attachment __attribute__((swift_name("attachment"))) __attribute__((deprecated("Will be removed. Inherit Buffer and add required fields instead.")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) RAMDKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end;

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface RAMDKtor_ioChunkBuffer : RAMDKtor_ioBuffer
- (instancetype)initWithMemory:(RAMDKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (RAMDKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (RAMDKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<RAMDKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next__) RAMDKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) RAMDKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end;

__attribute__((swift_name("Ktor_ioInput")))
@protocol RAMDKtor_ioInput <RAMDKtor_ioCloseable>
@required
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (int64_t)peekToDestination:(RAMDKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property RAMDKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default. Use readXXXLittleEndian or readXXX then X.reverseByteOrder() instead.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("KotlinAppendable")))
@protocol RAMDKotlinAppendable
@required
- (id<RAMDKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<RAMDKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<RAMDKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end;

__attribute__((swift_name("Ktor_ioOutput")))
@protocol RAMDKtor_ioOutput <RAMDKotlinAppendable, RAMDKtor_ioCloseable>
@required
- (id<RAMDKotlinAppendable>)appendCsq:(RAMDKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeByteV:(int8_t)v __attribute__((swift_name("writeByte(v:)")));
@property RAMDKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((deprecated("Write with writeXXXLittleEndian or do X.reverseByteOrder() and then writeXXX instead.")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioIoBuffer")))
@interface RAMDKtor_ioIoBuffer : RAMDKtor_ioChunkBuffer <RAMDKtor_ioInput, RAMDKtor_ioOutput>
- (instancetype)initWithContent:(void *)content contentCapacity:(int32_t)contentCapacity __attribute__((swift_name("init(content:contentCapacity:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (instancetype)initWithMemory:(RAMDKtor_ioMemory *)memory origin:(RAMDKtor_ioChunkBuffer * _Nullable)origin __attribute__((swift_name("init(memory:origin:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (id<RAMDKotlinAppendable>)appendValue:(unichar)c __attribute__((swift_name("append(value:)")));
- (id<RAMDKotlinAppendable>)appendCsq:(RAMDKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (id<RAMDKotlinAppendable>)appendValue_:(id _Nullable)csq __attribute__((swift_name("append(value_:)")));
- (id<RAMDKotlinAppendable>)appendValue:(id _Nullable)csq startIndex:(int32_t)start endIndex:(int32_t)end __attribute__((swift_name("append(value:startIndex:endIndex:)")));
- (int32_t)appendCharsCsq:(RAMDKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end:)")));
- (int32_t)appendCharsCsq:(id)csq start:(int32_t)start end_:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end_:)")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)discardCount_:(int64_t)n __attribute__((swift_name("discard(count_:)")));
- (RAMDKtor_ioIoBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)flush __attribute__((swift_name("flush()")));
- (RAMDKtor_ioIoBuffer *)makeView __attribute__((swift_name("makeView()")));
- (int64_t)peekToDestination:(RAMDKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)readDirectBlock:(RAMDInt *(^)(id))block __attribute__((swift_name("readDirect(block:)")));
- (void)releasePool_:(id<RAMDKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool_:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
- (void)writeByteValue:(int8_t)v __attribute__((swift_name("writeByte(value:)")));
- (int32_t)writeDirectBlock:(RAMDInt *(^)(id))block __attribute__((swift_name("writeDirect(block:)")));
@property RAMDKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface RAMDKtor_httpHeaderValueWithParameters : RAMDBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<RAMDKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<RAMDKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface RAMDKtor_httpContentType : RAMDKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<RAMDKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<RAMDKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(RAMDKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (RAMDKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (RAMDKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol RAMDKotlinx_coroutines_coreParentJob <RAMDKotlinx_coroutines_coreJob>
@required
- (RAMDKotlinx_coroutines_coreCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol RAMDKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<RAMDKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(RAMDKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(RAMDKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(RAMDKotlinx_coroutines_corePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<RAMDKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end;

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol RAMDKotlinSuspendFunction0 <RAMDKotlinFunction>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface RAMDKotlinKTypeProjection : RAMDBase
- (instancetype)initWithVariance:(RAMDKotlinKVariance * _Nullable)variance type:(id<RAMDKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
- (RAMDKotlinKVariance * _Nullable)component1 __attribute__((swift_name("component1()")));
- (id<RAMDKotlinKType> _Nullable)component2 __attribute__((swift_name("component2()")));
- (RAMDKotlinKTypeProjection *)doCopyVariance:(RAMDKotlinKVariance * _Nullable)variance type:(id<RAMDKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<RAMDKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) RAMDKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface RAMDKtor_ioMemory : RAMDBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
- (void)doCopyToDestination:(RAMDKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(RAMDKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (RAMDKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (RAMDKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end;

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol RAMDKtor_ioObjectPool <RAMDKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinCharArray")))
@interface RAMDKotlinCharArray : RAMDBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(id (^)(RAMDInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (RAMDKotlinCharIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(unichar)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface RAMDKtor_httpHeaderValueParam : RAMDBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (RAMDKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface RAMDKotlinx_coroutines_coreAtomicDesc : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(RAMDKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(RAMDKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property RAMDKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface RAMDKotlinx_coroutines_coreOpDescriptor : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(RAMDKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RAMDKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_corePrepareOp")))
@interface RAMDKotlinx_coroutines_corePrepareOp : RAMDKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(RAMDKotlinx_coroutines_coreLinkedListNode *)affected desc:(RAMDKotlinx_coroutines_coreAbstractAtomicDesc *)desc atomicOp:(RAMDKotlinx_coroutines_coreAtomicOp<id> *)atomicOp __attribute__((swift_name("init(affected:desc:atomicOp:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
@property (readonly) RAMDKotlinx_coroutines_coreLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) RAMDKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) RAMDKotlinx_coroutines_coreAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface RAMDKotlinKVariance : RAMDKotlinEnum<RAMDKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RAMDKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) RAMDKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) RAMDKotlinKVariance *out __attribute__((swift_name("out")));
- (int32_t)compareToOther:(RAMDKotlinKVariance *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinCharIterator")))
@interface RAMDKotlinCharIterator : RAMDBase <RAMDKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id)next_ __attribute__((swift_name("next_()")));
- (unichar)nextChar __attribute__((swift_name("nextChar()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface RAMDKotlinx_coroutines_coreAtomicOp<__contravariant T> : RAMDKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) RAMDKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLinkedListNode")))
@interface RAMDKotlinx_coroutines_coreLinkedListNode : RAMDBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(RAMDKotlinx_coroutines_coreLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(RAMDKotlinx_coroutines_coreLinkedListNode *)node condition:(RAMDBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(RAMDKotlinx_coroutines_coreLinkedListNode *)node predicate:(RAMDBoolean *(^)(RAMDKotlinx_coroutines_coreLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(RAMDKotlinx_coroutines_coreLinkedListNode *)node predicate:(RAMDBoolean *(^)(RAMDKotlinx_coroutines_coreLinkedListNode *))predicate condition:(RAMDBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(RAMDKotlinx_coroutines_coreLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(RAMDBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (RAMDKotlinx_coroutines_coreLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly) RAMDKotlinx_coroutines_coreLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) RAMDKotlinx_coroutines_coreLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAbstractAtomicDesc")))
@interface RAMDKotlinx_coroutines_coreAbstractAtomicDesc : RAMDKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(RAMDKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)failureAffected:(RAMDKotlinx_coroutines_coreLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(RAMDKotlinx_coroutines_coreLinkedListNode *)affected next:(RAMDKotlinx_coroutines_coreLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(RAMDKotlinx_coroutines_corePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (void)onComplete __attribute__((swift_name("onComplete()")));
- (id _Nullable)onPreparePrepareOp:(RAMDKotlinx_coroutines_corePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (id _Nullable)prepareOp:(RAMDKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
- (BOOL)retryAffected:(RAMDKotlinx_coroutines_coreLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
@property (readonly) RAMDKotlinx_coroutines_coreLinkedListNode *affectedNode __attribute__((swift_name("affectedNode")));
@end;

#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
